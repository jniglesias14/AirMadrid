package com.example.controladores.miCuenta

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.controladores.comprarBilletes.CompraBilletes
import com.example.controladores.login.InicioSesion
import com.example.controladores.miMundo.MiMundo
import com.example.controladores.misBilletes.misBilletes
import com.example.controladores.notificaciones.Notificaciones
import com.example.controladores.paginaPrincipal.PaginaPrincipal
import com.example.modelos.Usuario
import com.example.myapplication.R

/**
 * Actividad que permite gestionar y visualizar la información de la cuenta de usuario.
 * El usuario puede acceder a varias secciones como: compra de billetes, mis billetes,
 * ver notificaciones y explorar el "Mi Mundo".
 */
class MiCuenta : AppCompatActivity() {
    private lateinit var nombre:TextView
    private lateinit var apellido:TextView
    private lateinit var telefono:TextView
    private lateinit var dni:TextView
    private lateinit var username:TextView
    private lateinit var email:TextView
    private lateinit var wallet:ImageView
    private lateinit var home:ImageView
    private lateinit var Usuariodni:String
    private lateinit var misbilletes:ImageView
    private var conexionBD= ConexionBD()
    private lateinit var mundo:ImageView
    private lateinit var notificaciones:ImageView

    /**
     * Método llamado cuando se crea la actividad.
     *
     * Establece la vista, configura las vistas y los listeners de clic para las diferentes secciones,
     * y visualiza la información del usuario en la interfaz.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mi_cuenta)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val usuarioDNI = intent.getStringExtra("usuarioDNI")

        if (usuarioDNI != null) {
            Usuariodni=usuarioDNI
        }

        var res=conexionBD.dbConn()

        if(res==null) {
            toast_personalizado("Error de conexion con la BD")
        }



        nombre=findViewById(R.id.nombre)
        apellido=findViewById(R.id.apellido)
        telefono=findViewById(R.id.telefono)
        dni=findViewById(R.id.dni)
        username=findViewById(R.id.username)
        email=findViewById(R.id.email)
        wallet=findViewById(R.id.wallet)
        wallet.setOnClickListener {
            val intent = Intent(this, CompraBilletes::class.java)
            intent.putExtra("usuarioDNI", Usuariodni)
            startActivity(intent)

        }
        home=findViewById(R.id.home)
        home.setOnClickListener {
            val intent = Intent(this, PaginaPrincipal::class.java)
            intent.putExtra("usuarioDNI", Usuariodni)
            startActivity(intent)

        }
        misbilletes=findViewById(R.id.avion_despegue)
        misbilletes.setOnClickListener {
            val intent = Intent(this, misBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        mundo=findViewById(R.id.mundo)
        mundo.setOnClickListener {
            val intent = Intent(this, MiMundo::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        notificaciones=findViewById(R.id.mensaje_icono)
        notificaciones.setOnClickListener {
            val intent = Intent(this, Notificaciones::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        visualizarInformacion()


    }




    /**
     * Cierra la actividad actual y abre la pantalla de inicio de sesión.
     */
    fun cerrar(view: View){
        startActivity(Intent(this, InicioSesion::class.java))
    }
    /**
     * Obtiene y visualiza la información del usuario en la interfaz de usuario.
     */
    fun visualizarInformacion(){
        var user=Usuario("","",Usuariodni).datosUsuario(conexionBD)
        if (user != null) {
            nombre.text=" "+user.nombre
            apellido.text=" "+user.apellido1
            telefono.text=" "+user.telefono
            dni.text=" "+user.dni
            username.text=" "+user.nombre_usuario
            email.text=" "+user.email
        }
    }

    /**
     * Muestra un mensaje personalizado utilizando un Toast.
     *
     * @param texto El mensaje que se mostrará en el Toast.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }
}