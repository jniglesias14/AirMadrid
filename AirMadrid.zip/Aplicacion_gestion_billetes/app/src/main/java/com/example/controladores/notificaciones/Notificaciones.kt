package com.example.controladores.notificaciones

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.ListView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.controladores.comprarBilletes.CompraBilletes
import com.example.controladores.miCuenta.MiCuenta
import com.example.controladores.miMundo.MiMundo
import com.example.controladores.misBilletes.misBilletes
import com.example.controladores.paginaPrincipal.PaginaPrincipal
import com.example.modelos.Notificacion
import com.example.modelos.ReservaUsuario
import com.example.myapplication.R

/**
 * Actividad que muestra las notificaciones asociadas a las reservas del usuario.
 * La actividad obtiene las reservas del usuario desde la base de datos y genera una lista de notificaciones relacionadas con esos vuelos.
 * También gestiona la navegación hacia diferentes pantallas como la cuenta del usuario, la compra de billetes, etc.
 */
class Notificaciones : AppCompatActivity() {
    private lateinit var lista:ListView
    private var conexionBD= ConexionBD()
    private lateinit var usuario: ImageView
    private lateinit var misbilletes: ImageView
    private lateinit var mundo: ImageView
    private lateinit var home: ImageView
    private lateinit var wallet: ImageView
    private lateinit var usuarioDNI:String

    /**
     * Método que se llama cuando se crea la actividad. Configura la interfaz de usuario,
     * maneja la conexión con la base de datos y establece los clics de los botones para navegar entre las pantallas.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_notificaciones)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        conexionBD.dbConn()
        usuarioDNI = intent.getStringExtra("usuarioDNI").toString()

        var reservas=ReservaUsuario().getReservas(conexionBD,usuarioDNI)

        lista=findViewById(R.id.lista)

        var elementos=mutableListOf<Notificacion>()
        if(reservas.isNotEmpty()) {
            for (i in 0 until reservas.size) {
                var id_vuelo = reservas[i].id_vuelo

                elementos.addAll(reservas[i].getNotificacion(conexionBD, id_vuelo))

            }
        }





        val adaptador = NotificacionesAdapter(this, elementos)
        lista.adapter = adaptador




        wallet = findViewById(R.id.wallet)
        wallet.setOnClickListener {
            val intent = Intent(this, CompraBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        usuario = findViewById(R.id.user)
        usuario.setOnClickListener {
            val intent = Intent(this, MiCuenta::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }


        home = findViewById(R.id.home)
        home.setOnClickListener {
            val intent = Intent(this, PaginaPrincipal::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        mundo = findViewById(R.id.mundo)
        mundo.setOnClickListener {
            val intent = Intent(this, MiMundo::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        misbilletes = findViewById(R.id.avion_despegue)
        misbilletes.setOnClickListener {
            val intent = Intent(this, misBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }



    }
}