package com.example.modelos

import java.sql.PreparedStatement
import java.sql.ResultSet


/**
 * Clase que maneja las reservas de los usuarios en el sistema.
 * Permite insertar nuevas reservas, eliminar reservas existentes, y obtener las reservas y notificaciones asociadas.
 */
class ReservaUsuario (id_vuelo:String="",id_reserva:String="",fecha_salida:String="",dni_usuario:String="",fecha:String="",id_asiento:String="",nombre:String="",apellido1:String="",apellido2:String="",dni:String="",email:String="",telefono:String=""){

    var dni_usuario=dni_usuario
    var id_asiento=id_asiento
    var fecha=fecha
    var nombre=nombre
    var apellido1=apellido1
    var apellido2=apellido2
    var dni=dni
    var telefono=telefono
    var email=email
    var id_vuelo=id_vuelo
    var id_reserva=id_reserva
    var fecha_salida=fecha_salida



    /**
     * Inserta una nueva reserva en la base de datos.
     *
     * @param conexionBD Instancia de ConexionBD para establecer la conexión con la base de datos.
     * @param dni_usuario DNI del usuario que hace la reserva.
     * @param id_asiento ID del asiento reservado.
     * @param nombre Nombre del usuario.
     * @param apellido1 Primer apellido del usuario.
     * @param apellido2 Segundo apellido del usuario.
     * @param dni Documento de identidad del usuario.
     * @param email Correo electrónico del usuario.
     * @param telefono Teléfono de contacto del usuario.
     */
    fun insertarReserva(conexionBD: ConexionBD, dni_usuario:String, id_asiento:String, nombre:String, apellido1:String, apellido2:String, dni:String, email:String, telefono:String){
        try {
            val conn = conexionBD.dbConn()
            if (conn != null) {
                val sql = """
                    INSERT INTO reservas (dni_usuario, id_asiento_vuelo, fecha, nombre, apellido1, apellido2, dni, email, teléfono)
                    VALUES (?, ?, GETDATE(), ?, ?, ?, ?, ?, ?)
                """.trimIndent()
                val ps: PreparedStatement = conn.prepareStatement(sql)
                ps.setString(1, dni_usuario)
                ps.setInt(2, id_asiento.toInt())
                ps.setString(3, nombre)
                ps.setString(4, apellido1)
                ps.setString(5, apellido2)
                ps.setString(6, dni)
                ps.setString(7, email)
                ps.setString(8, telefono)

                ps.executeUpdate()

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }


    /**
     * Elimina una reserva de la base de datos.
     *
     * @param conexionBD Instancia de ConexionBD para la conexión con la base de datos.
     * @param usuarioDNI DNI del usuario cuya reserva se eliminará.
     * @param id_asiento_vuelo ID del asiento reservado en la reserva a eliminar.
     * @return `true` si la reserva se eliminó correctamente, `false` en caso contrario.
     */
    fun eliminarReserva(conexionBD: ConexionBD, usuarioDNI:String, id_asiento_vuelo:Int):Boolean{
        try {
            val conn = conexionBD.dbConn()
            if (conn != null) {
                val sql = "DELETE reservas where dni_usuario=? and id_asiento_vuelo = ?"
                val ps: PreparedStatement = conn.prepareStatement(sql)
                ps.setString(1, usuarioDNI)
                ps.setInt(2, id_asiento_vuelo)
                ps.executeUpdate()
                return true

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }

    /**
     * Obtiene las reservas del usuario para el día actual.
     *
     * @param conexionBD Instancia de ConexionBD para establecer la conexión con la base de datos.
     * @param dni_usuario DNI del usuario para el cual se buscan las reservas.
     * @return Lista de reservas para el día actual del usuario.
     */
    fun getReservasDia(conexionBD: ConexionBD, dni_usuario: String):MutableList<ReservaUsuario>{
        val registrosVacios = mutableListOf<ReservaUsuario>()
        try {

            val conn = conexionBD.dbConn()
            if (conn != null) {
                val query="SELECT r.id as reserva,av.id_vuelo as vuelo, v.fecha_salida as salida\n" +
                        "FROM reservas r\n" +
                        "JOIN asientos_vuelos av ON r.id_asiento_vuelo = av.id\n" +
                        "JOIN vuelos v ON av.id_vuelo = v.id\n" +
                        "WHERE CONVERT(DATE, v.fecha_salida) = CONVERT(DATE, GETDATE())\n and r.dni_usuario=?" +
                        "GROUP BY r.id, av.id_vuelo, v.fecha_salida;"

                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1,dni_usuario)
                val rs: ResultSet = statement.executeQuery()
                val registros = mutableListOf<ReservaUsuario>()
                while(rs.next()){
                    var reserva=ReservaUsuario()
                    reserva.id_reserva=rs.getInt("reserva").toString()
                    reserva.id_vuelo=rs.getString("vuelo")
                    reserva.fecha_salida=rs.getString("salida")
                    registros.add(reserva)
                }
                return registros

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return registrosVacios

    }

    /**
     * Obtiene todas las reservas de vuelos realizadas por el usuario.
     *
     * @param conexionBD Instancia de ConexionBD para la conexión con la base de datos.
     * @param dni_usuario DNI del usuario.
     * @return Lista de reservas de vuelos realizadas por el usuario.
     */
    fun getReservas(conexionBD: ConexionBD, dni_usuario: String):MutableList<ReservaUsuario>{
        val registrosVacios = mutableListOf<ReservaUsuario>()
        try {

            val conn = conexionBD.dbConn()
            if (conn != null) {
                val query="SELECT DISTINCT av.id_vuelo as vuelo\n" +
                        "FROM reservas r\n" +
                        "JOIN asientos_vuelos av ON r.id_asiento_vuelo = av.id\n" +
                        "WHERE r.dni_usuario = ?;\n;"

                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1,dni_usuario)
                val rs: ResultSet = statement.executeQuery()
                val registros = mutableListOf<ReservaUsuario>()
                while(rs.next()){
                    var reserva=ReservaUsuario()

                    reserva.id_vuelo=rs.getString("vuelo")

                    registros.add(reserva)
                }
                return registros

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return registrosVacios

    }

    /**
     * Obtiene las notificaciones asociadas a un vuelo específico.
     *
     * @param conexionBD Instancia de ConexionBD para la conexión con la base de datos.
     * @param id_vuelo ID del vuelo para el cual se desean obtener las notificaciones.
     * @return Lista de notificaciones asociadas al vuelo.
     */
    fun getNotificacion(conexionBD: ConexionBD, id_vuelo:String):MutableList<Notificacion>{
        val registrosVacios = mutableListOf<Notificacion>()
        try {
            val conn = conexionBD.dbConn()
            if (conn != null) {
                val sql = "SELECT id_vuelo AS vuelo, fecha, titulo, descripción\n" +
                        "FROM notificaciones_vuelos\n" +
                        "WHERE id_vuelo = \n?" +
                        "ORDER BY fecha DESC;"


                val ps: PreparedStatement = conn.prepareStatement(sql)
                ps.setString(1,id_vuelo)

                val rs: ResultSet = ps.executeQuery()
                var registros= mutableListOf<Notificacion>()
                while(rs.next()){
                    var notificacion=Notificacion()
                    notificacion.vuelo=rs.getString("vuelo")
                    notificacion.fecha=rs.getString("fecha")
                    notificacion.titulo=rs.getString("titulo")
                    notificacion.descripcion=rs.getString("descripción")
                    registros.add(notificacion)
                }
                return registros

            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return registrosVacios
    }


}