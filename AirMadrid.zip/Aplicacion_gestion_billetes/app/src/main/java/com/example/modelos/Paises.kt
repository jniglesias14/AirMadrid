package com.example.modelos

import java.sql.PreparedStatement
import java.sql.ResultSet

/**
 * Clase que representa los países y continentes que un usuario ha visitado en base a sus reservas.
 * Esta clase proporciona la funcionalidad de obtener la cantidad de ciudades diferentes visitadas
 * por un usuario dentro de un continente específico.
 *
 * @param dni_usuario El DNI del usuario.
 * @param continente El continente en el que el usuario ha visitado países.
 * @param visitas El número de ciudades diferentes visitadas por el usuario dentro de un continente.
 */
class Paises(dni_usuario:String="",continente:String="",visitas:Int=0) {

    var dni_usuario=dni_usuario
    var continente=continente
    var visitas=visitas



    /**
     * Obtiene los países y continentes que un usuario ha visitado, junto con la cantidad de ciudades
     * diferentes visitadas en esos continentes. Esto se obtiene a través de las reservas realizadas por el usuario.
     *
     * La consulta SQL une las tablas de reservas, vuelos, asientos de vuelos y países para contar las
     * ciudades distintas visitadas por un usuario en cada continente.
     *
     * @param conexionBD Instancia de `ConexionBD` que permite realizar la conexión con la base de datos.
     * @param usuario_dni El DNI del usuario del cual se desea obtener la información de los países y continentes visitados.
     * @return Una lista de objetos `Paises` con la información de los países y continentes visitados por el usuario.
     * Si no se encuentra ningún resultado, se retorna una lista vacía.
     */
    fun getPaisesContinentesVisitados(conexionBD: ConexionBD, usuario_dni:String):MutableList<Paises>{
        val registrosVacios = mutableListOf<Paises>()

        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {



                var query="SELECT \n" +
                        "    r.dni_usuario as dni,\n" +
                        "    p.continente as continente,\n" +
                        "    COUNT(DISTINCT v.id_ciudad_destino) AS cantidad_ciudades_diferentes\n" +
                        "FROM reservas r\n" +
                        "INNER JOIN asientos_vuelos av ON r.id_asiento_vuelo = av.id\n" +
                        "INNER JOIN vuelos v ON av.id_vuelo = v.id\n" +
                        "INNER JOIN paises p ON v.id_pais_destino = p.id\n" +
                        "WHERE r.dni_usuario = ?\n" +
                        "GROUP BY r.dni_usuario, p.continente\n" +
                        "ORDER BY r.dni_usuario, p.continente;\n"






                val statement: PreparedStatement = conn.prepareStatement(query)

                statement.setString(1,usuario_dni)




                val rs: ResultSet = statement.executeQuery()


                val registros = mutableListOf<Paises>()

                while (rs.next()) {
                    val continente = Paises()
                    continente.dni_usuario=rs.getString("dni")
                    continente.continente = rs.getString("continente")
                    continente.visitas = rs.getInt("cantidad_ciudades_diferentes")

                    registros.add(continente)
                }
                rs.close()
                statement.close()
                conn.close()
                return registros
            }else{

            }

        } catch (ex: Exception) {
            ex.printStackTrace()


        }
        return registrosVacios


}

}


