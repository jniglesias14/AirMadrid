package com.example.modelos

import android.os.StrictMode
import java.sql.Connection


import java.sql.DriverManager
import java.sql.SQLException

/**
 * Clase encargada de gestionar la conexión a la base de datos SQL Server.
 *
 * Configura los parámetros de conexión y permite establecer una conexión
 * utilizando el driver JTDS para SQL Server.
 *
 * @property ip Dirección IP y puerto del servidor de base de datos.
 * @property db Nombre de la base de datos.
 * @property username Nombre de usuario para autenticación.
 * @property password Contraseña para autenticación.
 */
class ConexionBD {
    private val ip="192.168.56.1:1433"
    private val db="AirMadrid"
    private val username="user"
    private val password="user"
    /**
     * Establece y devuelve una conexión a la base de datos.
     * Configura una política de permisos para permitir la conexión desde el hilo principal
     * (no recomendado en producción) y crea la conexión mediante JDBC.
     * @return Objeto Connection si se establece correctamente, o null si ocurre una excepción.
     */
    fun dbConn():Connection? {
        val policy=StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)
        var conn:Connection?=null
        val connString:String
        try{
            Class.forName("net.sourceforge.jtds.jdbc.Driver").newInstance();
            connString="jdbc:jtds:sqlserver://$ip;databaseName=$db;user=$username;password=$password"
            conn=DriverManager.getConnection(connString)
        }catch (ex:SQLException){
            ex.printStackTrace()
            return null
        }catch (ex1: ClassNotFoundException){
            ex1.printStackTrace()
            return null
        }catch (ex2: Exception){
            ex2.printStackTrace()
            return null
        }
        return conn
    }
}