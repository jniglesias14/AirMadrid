package com.example.controladores.login

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.modelos.Usuario
import com.example.myapplication.R


import kotlin.random.Random

/**
 * Actividad que maneja la recuperación de la contraseña de un usuario.
 *
 * Permite al usuario recuperar su contraseña al ingresar su DNI, recibir un código de verificación,
 * y luego ingresar una nueva contraseña.
 */

class RecuperacionContasena : AppCompatActivity() {
    private lateinit var send:TextView
    private lateinit var codigo:EditText
    private lateinit var contrasena1:EditText
    private lateinit var contrasena2:EditText
    private lateinit var confirmar:Button
    private lateinit var confirmar2:Button
    private lateinit var dni:EditText
    private var conexionBD= ConexionBD()
    private var codigoRec:Int=0

    /**
     * Método que se ejecuta cuando la actividad es creada.
     *
     * Configura la vista y los elementos UI, y maneja la lógica de la recuperación de contraseña.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recuperacion_contasena)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var res=conexionBD.dbConn()
        if(res==null) {
            toast_personalizado("Error de conexion con la BD")
        }

        codigo=findViewById(R.id.codigo)
        contrasena1=findViewById(R.id.contrasena1)
        contrasena2=findViewById(R.id.contrasena2)
        confirmar=findViewById(R.id.confirmar)
        confirmar2=findViewById(R.id.confirmar2)
        dni=findViewById(R.id.username)
        send=findViewById(R.id.send)

        send.setOnClickListener {
            if(Usuario("","",dni.text.toString()).comprobarDNI(conexionBD)){
                enviarNotificacion()
                send.visibility=View.GONE
                dni.visibility= View.GONE
                codigo.visibility=View.VISIBLE
                confirmar.visibility=View.VISIBLE

                confirmar.setOnClickListener {
                    if (codigo.text.toString().toInt() == codigoRec) {
                        codigo.visibility = View.GONE
                        confirmar.visibility = View.GONE
                        contrasena1.visibility = View.VISIBLE
                        contrasena2.visibility = View.VISIBLE
                        confirmar2.visibility = View.VISIBLE

                        confirmar2.setOnClickListener {
                            if (contrasena1.text.toString().length > 5 && contrasena2.text.toString().length > 5) {
                                if (contrasena1.text.toString() == contrasena2.text.toString()) {
                                    if (!Usuario(
                                            "",
                                            contrasena1.text.toString(),
                                            dni.text.toString()
                                        ).actualizarContrasena(conexionBD)
                                    ) {
                                        toast_personalizado("Error")
                                        startActivity(
                                            Intent(
                                                this,
                                                RecuperacionContasena::class.java
                                            )
                                        )
                                    } else {
                                        toast_personalizado2("Succesfully")
                                        startActivity(Intent(this, InicioSesion::class.java))
                                    }
                                } else {
                                    toast_personalizado("The password is incorrect")
                                    startActivity(Intent(this, RecuperacionContasena::class.java))
                                }
                            } else {
                                toast_personalizado("The password is incorrect")
                                startActivity(Intent(this, RecuperacionContasena::class.java))
                            }
                        }
                    } else {
                        toast_personalizado("The code is incorrect")
                        startActivity(Intent(this, RecuperacionContasena::class.java))
                    }
                }
            }else{
                toast_personalizado("DNI is incorrect")
                startActivity(Intent(this, RecuperacionContasena::class.java))
            }

        }

    }
    /**
     * Método que se ejecuta cuando el usuario presiona el botón "Atrás".
     * Redirige al usuario a la pantalla de inicio de sesión.
     */
    override fun onBackPressed() {
        super.onBackPressed()

        val intent = Intent(this, InicioSesion::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    /**
     * Muestra un toast personalizado con el mensaje recibido.
     *
     * @param texto El texto que se mostrará en el toast.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Envía una notificación al usuario con el código de recuperación.
     *
     * Esta notificación contiene el código de verificación necesario para continuar con la recuperación de la contraseña.
     */
   fun enviarNotificacion(){
        codigoRec=generarNumeroAleatorio()
       var canalId="aplicacion"
       var canalNombre="canal de notificaciones"

       val constructor=NotificationCompat.Builder(this,canalId).apply {
           setSmallIcon(R.drawable.avion_despegue)
           setLargeIcon(BitmapFactory.decodeResource(resources,R.drawable.terminales))
           setContentTitle("The code of verification is $codigoRec")
           setContentText("Dear user,\n" +
                   "We have received a request to reset your password. To proceed, please use the following recovery code: $codigoRec.\n" +
                   "If you did not request a password reset, please disregard this message.\n" +
                   "Thank you for using our service.")
           setPriority(NotificationCompat.PRIORITY_DEFAULT)
           setAutoCancel(true)

       }

       val notificador = getSystemService(NotificationManager::class.java)

       if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
           val canal=NotificationChannel(
               canalId,
               canalNombre,
               NotificationManager.IMPORTANCE_DEFAULT
           ).apply {
               description="This is the channel"
           }
          val notificador = getSystemService(NotificationManager::class.java)
           notificador.createNotificationChannel(canal)
       }
       val intent=Intent(this,this::class.java).apply {
           flags=Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
       }

       val pendingIntent=PendingIntent.getActivity(
           this,
           0,
           intent,
           PendingIntent.FLAG_IMMUTABLE
       )
       constructor.setContentIntent(pendingIntent)
       notificador.notify(0,constructor.build())

   }
    /**
     * Genera un número aleatorio entre 1000 y 9999.
     *
     * @return Un número aleatorio de 4 dígitos.
     */
    fun generarNumeroAleatorio(): Int {

        return Random.nextInt(1000, 10000)
    }
    /**
     * Muestra otro tipo de toast personalizado con el mensaje recibido.
     *
     * @param texto El texto que se mostrará en el toast.
     */
    fun toast_personalizado2(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast2, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }
}