package com.example.controladores.comprarBilletes

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.controladores.miCuenta.MiCuenta
import com.example.controladores.miMundo.MiMundo
import com.example.controladores.misBilletes.misBilletes
import com.example.controladores.notificaciones.Notificaciones
import com.example.myapplication.R
import com.example.controladores.paginaPrincipal.PaginaPrincipal
import com.example.modelos.Aerolinea
import com.example.modelos.Reserva
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * Pantalla para la compra de billetes de vuelo.
 * Permite al usuario seleccionar aerolínea, destino, fechas de ida y vuelta,
 * y buscar vuelos disponibles. Integra navegación hacia otras secciones de la app.
 */
class CompraBilletes : AppCompatActivity() {
    private lateinit var fecha: TextView
    private lateinit var fechaida: EditText
    private lateinit var fechavuelta: EditText
    private lateinit var home: ImageView
    private lateinit var usuario: ImageView
    private lateinit var Usuariodni: String
    private lateinit var misbilletes: ImageView
    private lateinit var aerolinea: Spinner
    private var conexionBD = ConexionBD()
    private lateinit var boton: Button
    private lateinit var destino: EditText
    private lateinit var mundo: ImageView
    private lateinit var notificaciones: ImageView

    /**
     * Método que se ejecuta al crear la actividad.
     * Inicializa vistas, configura listeners y conecta con la base de datos.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_compra_billetes)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets

        }
        var res = conexionBD.dbConn()

        if (res == null) {
            toast_personalizado("Error de conexion con la BD")
        }

        val usuarioDNI = intent.getStringExtra("usuarioDNI")
        if (usuarioDNI != null) {
            Usuariodni = usuarioDNI
        }

        fecha = findViewById(R.id.fecha)
        fechaida = findViewById(R.id.fechaida)
        fechavuelta = findViewById(R.id.fechallegada)
        usuario = findViewById(R.id.usuario)

        aerolinea = findViewById(R.id.aerolinea)
        boton = findViewById(R.id.boton)
        destino = findViewById(R.id.buscar)

        usuario.setOnClickListener {
            val intent = Intent(this, MiCuenta::class.java)
            intent.putExtra("usuarioDNI", Usuariodni)
            startActivity(intent)
        }
        home = findViewById(R.id.home)
        home.setOnClickListener {
            val intent = Intent(this, PaginaPrincipal::class.java)
            intent.putExtra("usuarioDNI", Usuariodni)
            startActivity(intent)
        }
        misbilletes = findViewById(R.id.avion_despegue)
        misbilletes.setOnClickListener {
            val intent = Intent(this, misBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        mundo = findViewById(R.id.mundo)
        mundo.setOnClickListener {
            val intent = Intent(this, MiMundo::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        notificaciones = findViewById(R.id.mensaje_icono)
        notificaciones.setOnClickListener {
            val intent = Intent(this, Notificaciones::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        val currentDate = Date()
        val dateFormat = SimpleDateFormat("EEEE dd 'de' MMMM 'de' yyyy", Locale("en", "US"))
        val formattedDate = dateFormat.format(currentDate)

        // Convertir la primera letra del día y del mes a mayúsculas
        val capitalizedDate = PaginaPrincipal().capitalizeFirstLetter(formattedDate)

        // Asignar la fecha formateada al TextView
        fecha.text = capitalizedDate

        fechaida.setOnClickListener {
            seleccionFechaIda()
        }
        fechavuelta.setOnClickListener {
            seleccionFechaVuelta()
        }


        var aerolineas = Aerolinea().getAerolineas(conexionBD)
        if (aerolineas != null) {
            aerolineas.add(0, Aerolinea("Selected an Aeroline . . ."))
        }
        if (aerolineas != null && aerolineas.isNotEmpty()) {

            val tiposAsientos =
                aerolineas.map { it.nombre } // Extrae los tipos de asiento de la lista

            // Crea un ArrayAdapter para el Spinner con un layout personalizado
            val adapter = object :
                ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, tiposAsientos) {
                override fun getView(
                    position: Int,
                    convertView: android.view.View?,
                    parent: android.view.ViewGroup
                ): android.view.View {
                    val view = super.getView(position, convertView, parent)
                    val textView = view as TextView
                    textView.setTextColor(resources.getColor(R.color.amarillo)) // Cambiar color del texto seleccionado
                    return view
                }

                override fun getDropDownView(
                    position: Int,
                    convertView: android.view.View?,
                    parent: android.view.ViewGroup
                ): android.view.View {
                    val view = super.getDropDownView(position, convertView, parent)
                    val textView = view as TextView

                    // Cambiar color del texto en el desplegable
                    textView.setTextColor(resources.getColor(R.color.black))

                    // Establecer el fondo del desplegable
                    view.setBackgroundResource(R.drawable.fondospinner)

                    return view
                }
            }

            // Establecer el layout para los elementos del spinner
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            aerolinea.adapter = adapter
        }
    }

    /**
     * Abre un DatePickerDialog para seleccionar la fecha de ida.
     */
    private fun seleccionFechaIda() {

        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)


        val datePickerDialog = DatePickerDialog(
            this, R.style.CustomDatePickerDialog,
            { _, selectedYear, selectedMonth, selectedDay ->

                val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                fechaida.setText(selectedDate)
            },
            year, month, day
        )


        datePickerDialog.show()
    }

    /**
     * Abre un DatePickerDialog para seleccionar la fecha de vuelta.
     * Solo permite seleccionar una fecha posterior a la de ida.
     */
    private fun seleccionFechaVuelta() {

        if (fechaida.text.isNotEmpty()) {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)


            val datePickerDialog = DatePickerDialog(
                this, R.style.CustomDatePickerDialog,
                { _, selectedYear, selectedMonth, selectedDay ->

                    val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                    val selectedDateObj = dateFormat.parse(selectedDate)
                    val idaDateObj = dateFormat.parse(fechaida.text.toString())


                    if (selectedDateObj != null && idaDateObj != null && selectedDateObj.after(
                            idaDateObj
                        )
                    ) {

                        fechavuelta.setText(selectedDate)
                    }
                },
                year, month, day
            )


            datePickerDialog.show()
        }
    }

    /**
     * Muestra un Toast personalizado con un mensaje.
     *
     * @param texto Mensaje a mostrar.
     */
    fun toast_personalizado(texto: String) {
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_LONG

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Método asociado al botón de buscar vuelos.
     * Realiza una búsqueda de vuelos en la base de datos y navega a la pantalla de reservas.
     *
     * @param view Vista que dispara el evento (botón buscar).
     */
    fun buscar(view: View) {

        val registros = Reserva().busquedaVuelosIda(
            conexionBD,
            destino.text.toString(),
            fechaida.text.toString(),
            fechavuelta.text.toString(),
            "",
            aerolinea.selectedItem.toString()
        )



        if (registros.isNotEmpty()) {


            val intent = Intent(this, ReservaVuelo::class.java)
            intent.putExtra("destino", destino.text.toString())
            intent.putExtra("fechaida", fechaida.text.toString())
            intent.putExtra("fechavuelta", fechavuelta.text.toString())
            intent.putExtra("aerolinea", aerolinea.selectedItem.toString())
            intent.putExtra("usuarioDNI", Usuariodni)
            startActivity(intent)


        } else {
            toast_personalizado("Not flights available ")
        }
    }


}