package com.example.controladores.paginaPrincipal

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.TooltipCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.FragmentContainerView
import com.example.modelos.ConexionBD
import com.example.controladores.comprarBilletes.CompraBilletes
import com.example.controladores.login.InicioSesion
import com.example.controladores.miCuenta.MiCuenta
import com.example.controladores.miMundo.MiMundo
import com.example.controladores.misBilletes.misBilletes
import com.example.controladores.notificaciones.Notificaciones
import com.example.modelos.Notificacion
import com.example.modelos.ReservaUsuario
import com.example.modelos.Vuelos
import com.example.myapplication.R
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


/**
 * Actividad principal del usuario tras iniciar sesión.
 * Muestra las opciones de navegación, vuelos y permite acceder a funcionalidades principales.
 */
class PaginaPrincipal : AppCompatActivity(),Comunicador {
    private lateinit var fecha:TextView
    private lateinit var wallet: ImageView
    private lateinit var terminales:ImageView
    private lateinit var puertas:ImageView
    private lateinit var wifi:ImageView
    private lateinit var comercios:ImageView
    private lateinit var taxi:ImageView
    private lateinit var cajero:ImageView
    private lateinit var usuario:ImageView
    private lateinit var UsuarioDNI: String
    private lateinit var listaVuelosSalidas:ListView
    private lateinit var listaVuelosLLegadas:ListView
    private lateinit var busqueda:EditText
    private lateinit var search:Button
    private lateinit var misbilletes:ImageView
    private var conexionBD= ConexionBD()
    private lateinit var mundo:ImageView
    private lateinit var notificaciones:ImageView
    private lateinit var handler: Handler
    private var runnable: Runnable= Runnable {}


    /**
     * Método que se ejecuta al crear la actividad.
     * Configura vistas, listeners y carga datos desde la base de datos.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pagina_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val usuarioDNI = intent.getStringExtra("usuarioDNI")
        if (usuarioDNI != null) {
            UsuarioDNI=usuarioDNI
        }
        var res=conexionBD.dbConn()

        if(res==null) {
            toast_personalizado("Error de conexion con la BD")
        }
        fecha=findViewById(R.id.fecha)
        wallet=findViewById(R.id.wallet)

        wallet.setOnClickListener {
            val intent = Intent(this, CompraBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        misbilletes=findViewById(R.id.avion_despegue)
        misbilletes.setOnClickListener {
            val intent = Intent(this, misBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        usuario=findViewById(R.id.usuario)

        usuario.setOnClickListener {
            val intent = Intent(this, MiCuenta::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        mundo=findViewById(R.id.mundo)
        mundo.setOnClickListener {
            val intent = Intent(this, MiMundo::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }


        terminales=findViewById(R.id.terminales)
        puertas=findViewById(R.id.puertas)
        wifi=findViewById(R.id.wifi)
        comercios=findViewById(R.id.comercios)
        cajero=findViewById(R.id.cajero)
        taxi=findViewById(R.id.taxi)
        listaVuelosSalidas=findViewById(R.id.lista)
        listaVuelosLLegadas=findViewById(R.id.lista2)
        busqueda=findViewById(R.id.busqueda)
        search=findViewById(R.id.search)


        TooltipCompat.setTooltipText(terminales, "Terminals")
        TooltipCompat.setTooltipText(puertas, "Boarding Gates")
        TooltipCompat.setTooltipText(wifi, "Wifi")
        TooltipCompat.setTooltipText(comercios, "Shops")
        TooltipCompat.setTooltipText(cajero, "Cashiers")
        TooltipCompat.setTooltipText(taxi, "Taxi")

        val currentDate = Date()
        val dateFormat = SimpleDateFormat("EEEE dd 'de' MMMM 'de' yyyy", Locale("en", "US"))
        val formattedDate = dateFormat.format(currentDate)


        val capitalizedDate = capitalizeFirstLetter(formattedDate)


        fecha.text = capitalizedDate


        var elementos= mutableListOf<Vuelos>()
        var elementos2= mutableListOf<Vuelos>()
        var registros=Vuelos().getInformacionVuelosSalidas(conexionBD)
        var registros2=Vuelos().getInformacionVuelosLlegadas(conexionBD)
        if(registros!=null){
            for(i in 0 until registros.size){

                elementos.add(registros[i])
            }

        }

        if(registros2!=null){
            for(i in 0 until registros2.size){

                elementos2.add(registros2[i])
            }

        }

        val adaptador= VueloAdapter(
            this,
            elementos
        )
        listaVuelosSalidas.adapter=adaptador

        val adaptador2= VueloAdapter(
            this,
            elementos2
        )
        listaVuelosLLegadas.adapter=adaptador2
        
        
        listaVuelosSalidas.setOnItemClickListener { _, _, position,_  ->
            val vueloSeleccionado = elementos[position]


            val idVuelo = vueloSeleccionado.id_vuelo
                pasarId(idVuelo)
        }
        listaVuelosLLegadas.setOnItemClickListener { _, _, position,_  ->
            val vueloSeleccionado = elementos2[position]


            val idVuelo = vueloSeleccionado.id_vuelo
            pasarId(idVuelo)
        }


        var reservas= mutableListOf<ReservaUsuario>()
        reservas=ReservaUsuario().getReservasDia(conexionBD, UsuarioDNI)


        handler = Handler(mainLooper)

        if(reservas.isNotEmpty()){

            var registrousuariocompravuelo=intent.getStringExtra("RegistroUsuarioCompraVuelo")
            if (registrousuariocompravuelo!=null){
                iniciarComparacion(reservas)
            }else{

                handler.removeCallbacks(runnable)

                iniciarComparacion(reservas)
            }

     }

        notificaciones=findViewById(R.id.mensaje_icono)
        notificaciones.setOnClickListener {
            val intent = Intent(this, Notificaciones::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

    }

    /**
     * Inicia la comparación de las fechas de reserva con la fecha actual para gestionar notificaciones.
     */
    fun iniciarComparacion(reservas: List<ReservaUsuario>) {
        runnable = object : Runnable {
            override fun run() {
                var comparacionFinalizada = false
                for (reserva in reservas) {
                    comparacionFinalizada = verificarFecha(reserva)
                    if (comparacionFinalizada) break
                }
                if (!comparacionFinalizada) {
                    handler.postDelayed(this, 5000)
                }
            }
        }
        handler.post(runnable)
    }

    /**
     * Obtiene la fecha actual con zona horaria de Madrid.
     */
    fun obtenerFechaActualEnEspana(): Date {

        val calendar = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Madrid"))


        calendar.add(java.util.Calendar.HOUR_OF_DAY, 2)

        return calendar.time
    }

    /**
     * Compara la fecha de reserva menos 55 minutos con la fecha actual y gestiona notificaciones.
     */
    fun verificarFecha(reserva:ReservaUsuario):Boolean{
        var fechaReservaMenos=Date()
        val fecha_actual = obtenerFechaActualEnEspana()
        val fecha_reserva_formateada = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).parse(reserva.fecha_salida)
        fecha_reserva_formateada?.let {
             fechaReservaMenos = Date(it.time - (60 * 60 * 1000))  // 30 min en milisegundos
        }
        if ( compararFechas(fechaReservaMenos, fecha_actual)==0) {
            if(Notificacion().comprobarNotificacion(conexionBD,reserva.id_vuelo)){
                Notificacion().insertarNotificacion(conexionBD,reserva.id_vuelo)
            }
            return true
        }else if(compararFechas(fechaReservaMenos, fecha_actual)==-1){
            if(Notificacion().comprobarNotificacion(conexionBD,reserva.id_vuelo)){
                Notificacion().insertarNotificacion(conexionBD,reserva.id_vuelo).toString()
            }
            return true
        }else{

            return false
        }
    }



    /**
     * Compara dos fechas y devuelve:
     * 1 si la primera es posterior
     * 0 si son iguales
     * -1 si la primera es anterior
     */
    fun compararFechas(fecha_salida: Date, fecha_actual: Date): Int {
        return when {
            fecha_salida.after(fecha_actual) -> 1
            fecha_salida == fecha_actual -> 0
            else -> -1
        }
    }

    /**
     * Sobreescribe el comportamiento del botón atrás.
     * Redirige a la pantalla de inicio de sesión y limpia el backstack.
     */
    override fun onBackPressed() {
        super.onBackPressed()

        val intent = Intent(this, InicioSesion::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    /**
     * Capitaliza la primera letra de cada palabra en una cadena.
     */
    fun capitalizeFirstLetter(date: String): String {

        return date.split(" ").joinToString(" ") { it.capitalize(Locale("es", "ES")) }
    }

    /**
     * Muestra un Toast personalizado con un mensaje.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Abre un fragmento de detalle de vuelo con el ID proporcionado.
     */
    override fun pasarId(id:String) {

        val paquete = Bundle()
        paquete.putString("id", id)
        paquete.putString("usuarioDNI",UsuarioDNI)

        val frag = visualizacion_vuelo()
        frag.arguments = paquete
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragmento, frag)
        transaction.addToBackStack(null)
        transaction.commit()
        val fragmentContainer = findViewById<FragmentContainerView>(R.id.fragmento)
        fragmentContainer.visibility = View.VISIBLE


    }

    /**
     * Realiza una búsqueda de vuelo por ID y muestra su detalle si existe.
     */
    fun search(view:View){
        if(Vuelos().getInformacionVuelo(conexionBD,busqueda.text.toString())!=null){
            pasarId(busqueda.text.toString())
        }else{
            toast_personalizado("This flight doesn´t exist")
        }
    }
}