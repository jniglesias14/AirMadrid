package com.example.controladores.notificaciones

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.modelos.Notificacion
import com.example.modelos.Vuelos
import com.example.myapplication.R

/**
 * Adaptador para mostrar una lista de notificaciones en una vista.
 * Este adaptador se encarga de inflar las vistas necesarias para cada elemento de la lista de notificaciones.
 *
 * @param contexto El contexto en el que se va a utilizar el adaptador (generalmente la actividad o fragmento).
 * @param notificaciones Lista de objetos Notificacion que se van a mostrar en la vista.
 */
class NotificacionesAdapter(var contexto: Context, var notificaciones:List<Notificacion>):BaseAdapter() {

    /**
     * Obtiene la cantidad de elementos en la lista de notificaciones.
     *
     * @return El número total de notificaciones en la lista.
     */
    override fun getCount(): Int {
        return notificaciones.size
    }

    /**
     * Obtiene el elemento en una posición específica de la lista de notificaciones.
     *
     * @param position La posición del elemento en la lista.
     * @return El objeto Notificacion correspondiente a la posición.
     */
    override fun getItem(position: Int): Any {
        return notificaciones[position]
    }

    /**
     * Obtiene el ID de un elemento en la lista. Este ID se usa generalmente para la selección en la lista.
     *
     * @param position La posición del elemento.
     * @return El ID de la notificación (en este caso, la posición).
     */
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    /**
     * Infla y devuelve una vista para un elemento en la lista de notificaciones.
     *
     * @param position La posición del elemento dentro de la lista.
     * @param convertView Una vista reciclada para evitar la creación de nuevas vistas innecesarias (optimización de memoria).
     * @param parent El contenedor principal que contiene la vista inflada.
     * @return La vista inflada con la información de la notificación en esa posición.
     */
    @SuppressLint("SuspiciousIndentation")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(contexto).inflate(
            R.layout.mensaje,
            parent,
            false
        )

        var fecha: TextView = view.findViewById(R.id.fecha)
        var titulo: TextView = view.findViewById(R.id.titulo)
        var vuelo: TextView = view.findViewById(R.id.vuelo)
        var descripcion: TextView = view.findViewById(R.id.descripcion)


        fecha.text=notificaciones[position].fecha
        titulo.text=notificaciones[position].titulo
        vuelo.text=notificaciones[position].vuelo
        descripcion.text=notificaciones[position].descripcion


        return view


    }
}