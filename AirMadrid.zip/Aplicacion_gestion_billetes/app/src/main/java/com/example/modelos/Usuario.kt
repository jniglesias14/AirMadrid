package com.example.modelos


import java.sql.PreparedStatement
import java.sql.ResultSet

/**
 * Clase que representa un usuario del sistema.
 * Contiene atributos personales y métodos para autenticación y gestión de usuarios en base de datos.
 */
class Usuario(nombre_usuario:String,password:String="",dni:String="",nombre:String="",apellido1:String="",apellido2:String="",fecha_nac:String="",telefono:String="",email:String="") {
    var dni=dni
    var nombre=nombre
    var apellido1= apellido1
    var apellido2=apellido2
    var fecha_nac=fecha_nac
    var telefono=telefono
    var email=email
    var nombre_usuario=nombre_usuario
    var password=password

    /**
     * Comprueba si existe un usuario con nombre de usuario y contraseña.
     */
    fun comprobarUsuario(conexionBD: ConexionBD):Boolean{

        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "SELECT * FROM usuarios WHERE nombre_usuario = ? AND password = ?"
                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1, this.nombre_usuario)
                statement.setString(2, this.password)


                val resultSet: ResultSet = statement.executeQuery()


                if(resultSet.next()){
                    resultSet.close()
                    statement.close()
                    conn.close()
                    return true
                }

            }
        } catch (ex: Exception) {
            ex.printStackTrace()
            return false
        }
        return false

    }

    /**
     * Comprueba si existe un nombre de usuario registrado.
     */
    fun comprobarUsername(conexionBD: ConexionBD):Boolean{

        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "SELECT * FROM usuarios WHERE nombre_usuario = ? "
                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1, this.nombre_usuario)



                val resultSet: ResultSet = statement.executeQuery()


                if(resultSet.next()){
                    resultSet.close()
                    statement.close()
                    conn.close()
                    return true
                }

            }
        } catch (ex: Exception) {
            ex.printStackTrace()
            return false
        }
        return false

    }

    /**
     * Comprueba si existe un DNI registrado.
     */
    fun comprobarDNI(conexionBD: ConexionBD):Boolean{
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "SELECT * FROM usuarios WHERE dni = ? "
                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1, this.dni)



                val rs: ResultSet = statement.executeQuery()


                if(rs.next()) {

                    rs.close()
                    statement.close()
                    conn.close()
                    return true
                }


            }
        } catch (ex: Exception) {
            ex.printStackTrace()
            return false
        }
        return false
    }


    /**
     * Obtiene el DNI de un usuario dado su nombre de usuario y contraseña.
     */
    fun devolverDNI(conexionBD: ConexionBD):String{
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "SELECT dni FROM usuarios WHERE  nombre_usuario = ? AND password = ? "
                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1, this.nombre_usuario)
                statement.setString(2, this.password)


                val rs: ResultSet = statement.executeQuery()


                var dniUser=""
                if(rs.next()) {
                    dniUser=rs.getString("dni")

                }
                rs.close()
                statement.close()
                conn.close()
                return dniUser


            }
        } catch (ex: Exception) {
            ex.printStackTrace()
            return ""
        }
        return ""
    }


    /**
     * Actualiza la contraseña del usuario según su DNI.
     */
    fun actualizarContrasena(conexionBD: ConexionBD):Boolean{
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "UPDATE  usuarios SET password=? WHERE dni = ? "
                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1, this.password)
                statement.setString(2, this.dni)

                val rowsUpdated = statement.executeUpdate()


                if (rowsUpdated > 0) {
                    return true
                } else {
                    return false
                }
            }
            } catch (ex: Exception) {
            ex.printStackTrace()
            return false
            }
            return false
    }

    /**
     * Inserta un nuevo usuario en la base de datos.
     */
    fun insertarUsuario(conexionBD: ConexionBD):Boolean{
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "INSERT INTO usuarios (nombre_usuario, password, dni, nombre, apellido1, fecha_nac, teléfono, email) VALUES (?, ?, ?, ?, ?, ?, ?, ?) "
                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1, this.nombre_usuario)
                statement.setString(2, this.password)
                statement.setString(3, this.dni)
                statement.setString(4, this.nombre)
                statement.setString(5, this.apellido1)
                statement.setString(6, this.fecha_nac)
                statement.setString(7, this.telefono)
                statement.setString(8, this.email)

                val rowsUpdated = statement.executeUpdate()


                if (rowsUpdated > 0) {
                    return true
                } else {
                    return false
                }
            }
        } catch (ex: Exception) {
            ex.printStackTrace()
            return false
        }
        return false
    }

    /**
     * Obtiene los datos personales de un usuario por su DNI.
     */
    fun datosUsuario(conexionBD: ConexionBD): Usuario? {
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "SELECT * FROM usuarios WHERE dni = ? "
                val statement: PreparedStatement = conn.prepareStatement(query)
                statement.setString(1, this.dni)



                val rs: ResultSet = statement.executeQuery()


                var usuario=Usuario("")
                if(rs.next()) {
                    usuario.dni=rs.getString("dni")
                    usuario.nombre=rs.getString("nombre")
                    usuario.apellido1=rs.getString("apellido1")
                    usuario.telefono=rs.getString("teléfono")
                    usuario.email=rs.getString("email")
                    usuario.nombre_usuario=rs.getString("nombre_usuario")
                }

                rs.close()
                statement.close()
                conn.close()
                return usuario

            }
        } catch (ex: Exception) {
            ex.printStackTrace()

        }
        return null
    }


}

