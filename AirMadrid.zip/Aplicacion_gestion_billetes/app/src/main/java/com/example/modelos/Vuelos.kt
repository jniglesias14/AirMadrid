package com.example.modelos

import java.sql.PreparedStatement
import java.sql.ResultSet

/**
 * Clase que representa un vuelo.
 *
 * @property fecha_salida Fecha y hora de salida.
 * @property destino Destino del vuelo.
 * @property id_vuelo Identificador del vuelo.
 * @property terminal Terminal de salida o llegada.
 * @property puerta_embarque Puerta de embarque.
 * @property estado Estado actual del vuelo.
 * @property fecha_llegada Fecha y hora de llegada.
 * @property origen Origen del vuelo.
 * @property aerolinea Aerolínea del vuelo.
 * @property avion Identificador del avión.
 * @property enlace Enlace a la web de la aerolínea.
 * @property modelo Modelo del avión.
 */
class Vuelos (fecha_salida:String="",destino:String="", id_vuelo:String="", terminal:String="",puerta_embarque:String="",estado:String="",fecha_llegada:String="",origen:String="",aerolinea:String="",avion:String="",enlace:String="",modelo:String=""){
    var fecha_salida=fecha_salida
    var destino=destino
    var id_vuelo=id_vuelo
    var terminal=terminal
    var puerta_embarque=puerta_embarque
    var estado=estado
    var fecha_llegada=fecha_llegada
    var origen=origen
    var aerolinea=aerolinea
    var avion=avion
    var enlace=enlace
    var modelo=modelo

    /**
     * Obtiene una lista de vuelos de salida desde Madrid para una fecha específica.
     *
     * @param conexionBD Conexión a la base de datos.
     * @param fecha Fecha a consultar (formato YYYY-MM-DD).
     * @return Lista de objetos Vuelos o null en caso de error.
     */
    fun getInformacionVuelosSalidas(conexionBD: ConexionBD, fecha:String="2025-05-21") :MutableList<Vuelos>?{
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "SELECT FORMAT(v.fecha_salida, 'HH:mm:ss') as fecha,v.id_ciudad_destino as destino,v.id as vuelo,v.id_terminal as terminal,v.id_puerta_embarque as puerta,v.estado as estado FROM vuelos v WHERE v.id_ciudad_origen = 'MAD' AND CAST(v.fecha_salida AS DATE) = '2025-05-21' ORDER BY v.fecha_llegada; "

                val statement: PreparedStatement = conn.prepareStatement(query)

                val rs: ResultSet = statement.executeQuery()


                val registros = mutableListOf<Vuelos>()

                while(rs.next()){

                    val vuelo=Vuelos()
                    vuelo.fecha_salida=rs.getString("fecha")
                    vuelo.destino=rs.getString("destino")
                    vuelo.id_vuelo=rs.getString("vuelo")
                    vuelo.terminal=rs.getString("terminal")
                    vuelo.puerta_embarque=rs.getString("puerta")
                    vuelo.estado=rs.getString("estado")
                    registros.add(vuelo)
                }

                rs.close()
                statement.close()
                conn.close()
                return registros
            }else{

            }

        } catch (ex: Exception) {
            ex.printStackTrace()
            return null

        }
        return null
    }

    /**
     * Obtiene una lista de vuelos de llegada a Madrid para una fecha específica.
     *
     * @param conexionBD Conexión a la base de datos.
     * @param fecha Fecha a consultar (formato YYYY-MM-DD).
     * @return Lista de objetos Vuelos o null en caso de error.
     */
    fun getInformacionVuelosLlegadas(conexionBD: ConexionBD, fecha:String="2025-05-21") :MutableList<Vuelos>?{
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "SELECT FORMAT(v.fecha_llegada, 'HH:mm:ss') as fecha,v.id_ciudad_origen as origen,v.id as vuelo,v.id_terminal as terminal,v.id_puerta_embarque as puerta,v.estado as estado FROM vuelos v WHERE v.id_ciudad_destino = 'MAD' AND CAST(v.fecha_llegada AS DATE) = '2025-05-21' ORDER BY v.fecha_llegada; "

                val statement: PreparedStatement = conn.prepareStatement(query)





                val rs: ResultSet = statement.executeQuery()


                val registros = mutableListOf<Vuelos>()

                while(rs.next()){

                    val vuelo=Vuelos()
                    vuelo.fecha_salida=rs.getString("fecha")
                    vuelo.destino=rs.getString("origen")
                    vuelo.id_vuelo=rs.getString("vuelo")
                    vuelo.terminal=rs.getString("terminal")
                    vuelo.puerta_embarque=rs.getString("puerta")
                    vuelo.estado=rs.getString("estado")
                    registros.add(vuelo)
                }

                rs.close()
                statement.close()
                conn.close()
                return registros
            }else{

            }

        } catch (ex: Exception) {
            ex.printStackTrace()
            return null

        }
        return null
    }

    /**
     * Obtiene información detallada de un vuelo por su ID.
     *
     * @param conexionBD Conexión a la base de datos.
     * @param id Identificador del vuelo.
     * @return Objeto Vuelos con los datos recuperados o null si no se encuentra.
     */
    fun getInformacionVuelo(conexionBD: ConexionBD, id:String) :Vuelos?{
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = " select v.id as vuelo,  c.nombre as origen,   ci.nombre as destino,  v.fecha_salida as fecha_salida,    v.fecha_llegada as fecha_llegada,    v.id_terminal as terminal,   v.id_puerta_embarque as puerta,    aerolinea.nombre as aerolinea,    aerolinea.enlace_web as enlace,   aviones.id as avion,     aviones.modelo as modelo\n" +
                        "from aerolíneas aerolinea\n" +
                        "join aviones aviones on aviones.id_aerolinea=aerolinea.id\n" +
                        "join vuelos v on v.id_avion=aviones.id and v.id_aerolinea=aviones.id_aerolinea\n" +
                        "join ciudades c on c.id=v.id_ciudad_origen and c.id_pais=v.id_pais_origen\n" +
                        "join ciudades ci on ci.id=v.id_ciudad_destino and ci.id_pais=v.id_pais_destino where v.id=?; "

                val statement: PreparedStatement = conn.prepareStatement(query)

                statement.setString(1, id)



                val rs: ResultSet = statement.executeQuery()



                val vuelo=Vuelos()
                if(rs.next()){

                    vuelo.id_vuelo=rs.getString("vuelo")
                    vuelo.origen=rs.getString("origen")
                    vuelo.destino = rs.getString("destino")
                    vuelo.fecha_salida = rs.getString("fecha_salida")
                    vuelo.fecha_llegada = rs.getString("fecha_llegada")
                    vuelo.terminal = rs.getString("terminal")
                    vuelo.puerta_embarque = rs.getString("puerta")
                    vuelo.aerolinea = rs.getString("aerolinea")
                    vuelo.enlace = rs.getString("enlace")
                    vuelo.avion=rs.getString("avion")
                    vuelo.modelo = rs.getString("modelo")

                    rs.close()
                    statement.close()
                    conn.close()
                    return vuelo

                }

                rs.close()
                statement.close()
                conn.close()
                return null
            }else{

            }

        } catch (ex: Exception) {
            ex.printStackTrace()
            return null

        }
        return null
    }

    /**
     * Obtiene el origen o destino de un vuelo, dependiendo si sale o llega desde Madrid.
     *
     * @param conexionBD Conexión a la base de datos.
     * @param id_vuelo Identificador del vuelo.
     * @return Nombre de la ciudad de origen o destino.
     */
    fun getOrigenDestino(conexionBD: ConexionBD, id_vuelo: String):String{
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "select c.nombre as origen, ci.nombre as destino\n" +
                        "from vuelos v\n" +
                        "join ciudades c on c.id=v.id_ciudad_origen and c.id_pais=v.id_pais_origen\n" +
                        "join ciudades ci on ci.id=v.id_ciudad_destino and ci.id_pais=v.id_pais_destino\n" +
                        "where v.id=?"

                val statement: PreparedStatement = conn.prepareStatement(query)

                statement.setString(1, id_vuelo)



                val rs: ResultSet = statement.executeQuery()



                val vuelo=Vuelos()
                if(rs.next()){

                    vuelo.origen=rs.getString("origen")
                    vuelo.destino = rs.getString("destino")



                }

                rs.close()
                statement.close()
                conn.close()
                if(vuelo.origen=="Madrid"){
                    return vuelo.origen
                }else{
                    return vuelo.destino
                }
            }else{

            }

        } catch (ex: Exception) {
            ex.printStackTrace()
            return ""

        }
        return ""
    }
}