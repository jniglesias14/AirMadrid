package com.example.controladores.comprarBilletes

/**
 * Interfaz para comunicar datos de un vuelo de ida seleccionado
 * desde un fragmento o actividad hacia otra actividad o fragmento.
 */
interface Comunicador2 {
    /**
     * Método para pasar los datos de un vuelo de ida seleccionado.
     *
     * @param id ID del vuelo seleccionado.
     * @param fecha_vuelta Fecha de vuelta seleccionada por el usuario.
     * @param aerolinea Nombre de la aerolínea seleccionada.
     * @param usuarioDni DNI del usuario que realiza la búsqueda.
     */
    fun pasarDatosVuelosIda(id:String,fecha_vuelta:String,aerolinea:String,usuarioDni:String)
}