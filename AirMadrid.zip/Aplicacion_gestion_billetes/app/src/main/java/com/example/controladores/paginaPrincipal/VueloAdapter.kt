package com.example.controladores.paginaPrincipal

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.modelos.Vuelos
import com.example.myapplication.R

/**
 * Adaptador personalizado para mostrar una lista de objetos Vuelos en una ListView.
 *
 * Esta clase extiende de BaseAdapter y se encarga de crear y configurar
 * las vistas de cada elemento (fila) de la lista, utilizando el layout registro_vuelo.
 *
 * @param contexto El contexto de la aplicación.
 * @param vuelos La lista de vuelos que se van a mostrar.
 */

class VueloAdapter(var contexto: Context, var vuelos:List<Vuelos>): BaseAdapter() {

    /**
     * Devuelve la cantidad de elementos en la lista de vuelos.
     *
     * @return Número de elementos en la lista.
     */
    override fun getCount(): Int {
        return vuelos.size
    }

    /**
     * Devuelve el objeto Vuelo en la posición especificada.
     *
     * @param position La posición del elemento.
     * @return El objeto Vuelo en esa posición.
     */
    override fun getItem(position: Int): Any {
        return vuelos[position]
    }

    /**
     * Devuelve el ID del elemento en la posición especificada.
     * En este caso, se usa la posición como ID.
     *
     * @param position La posición del elemento.
     * @return ID del elemento.
     */
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    /**
     * Crea y configura la vista para cada elemento de la lista de vuelos.
     * Si se puede, reutiliza una vista existente (convertView) para optimizar el rendimiento.
     *
     * @param position La posición del elemento dentro de los datos.
     * @param convertView La vista reciclada que se puede reutilizar.
     * @param parent El ViewGroup al que se adjunta esta vista.
     * @return La vista configurada para el elemento.
     */
    @SuppressLint("SuspiciousIndentation")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(contexto).inflate(
            R.layout.registro_vuelo,
            parent,
            false
        )

        var fecha: TextView = view.findViewById(R.id.hora)
        val destino: TextView = view.findViewById(R.id.destino)
        val vuelo: TextView = view.findViewById(R.id.vuelo)
        var terminal: TextView = view.findViewById(R.id.terminal)
        val puerta: TextView = view.findViewById(R.id.puerta)
        val estado: TextView = view.findViewById(R.id.estado)

        fecha.text=vuelos[position].fecha_salida
        destino.text =vuelos[position].destino
        vuelo.text =vuelos[position].id_vuelo
        terminal.text=vuelos[position].terminal
        puerta.text =vuelos[position].puerta_embarque
        estado.text =vuelos[position].estado

            return view


    }

}