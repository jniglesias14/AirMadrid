package com.example.modelos

import android.annotation.SuppressLint
import java.sql.PreparedStatement
import java.sql.ResultSet

/**
 * Clase que representa una reserva de vuelo, incluyendo detalles sobre el vuelo, aerolínea, asiento, y los datos del pasajero.
 * Esta clase proporciona métodos para realizar consultas sobre vuelos disponibles y las reservas del usuario.
 *
 * @param id_vuelo El identificador único del vuelo.
 * @param aerolinea El nombre de la aerolínea.
 * @param destino La ciudad de destino del vuelo.
 * @param origen La ciudad de origen del vuelo.
 * @param fecha_salida La fecha de salida del vuelo.
 * @param fecha_llegada La fecha de llegada del vuelo.
 * @param id_avion El identificador del avión que realizará el vuelo.
 * @param numero El número del asiento reservado.
 * @param letra La letra del asiento reservado.
 * @param tipo El tipo de asiento (Ej. clase económica, primera clase, etc.).
 * @param precio El precio del billete.
 * @param estado El estado de la reserva (Ej. Confirmada, Cancelada, etc.).
 * @param enlace El enlace de la aerolínea para más detalles.
 * @param nombre El nombre del pasajero.
 * @param apellido El apellido del pasajero.
 * @param fecha La fecha de la reserva.
 * @param id_asiento El identificador del asiento reservado.
 */
class Reserva(id_vuelo:String="",aerolinea:String="",destino:String="",origen:String="",fecha_salida:String="",fecha_llegada:String="",id_avion:String="",numero:String="",letra:String="",tipo:String="",precio:String="",estado:String="",enlace:String="",nombre:String="",apellido:String="",fecha:String="",id_asiento:String="") {
    var id_vuelo=id_vuelo
    var aerolinea=aerolinea
    var destino=destino
    var origen=origen
    var fecha_salida = fecha_salida
    var fecha_llegada = fecha_llegada
    var id_avion = id_avion
    var numero = numero
    var letra = letra
    var tipo = tipo
    var precio = precio
    var estado = estado
    var enlace=enlace
    var nombre=nombre
    var apellido=apellido
    var fecha=fecha
    var id_asiento=id_asiento

    /**
     * Realiza una búsqueda de vuelos de ida basándose en el destino, la fecha de ida, la fecha de vuelta, la clase y la aerolínea seleccionados.
     * Devuelve una lista de vuelos disponibles que cumplen con los criterios de búsqueda.
     *
     * @param conexionBD Instancia de `ConexionBD` que permite realizar la conexión con la base de datos.
     * @param destino El destino del vuelo.
     * @param fechaIda La fecha de ida del vuelo.
     * @param fechaVuelta La fecha de vuelta del vuelo.
     * @param clase La clase de vuelo seleccionada (Ej. primera clase, clase económica, etc.).
     * @param aerolinea La aerolínea seleccionada.
     * @return Una lista de objetos `Reserva` con los vuelos disponibles que coinciden con los criterios de búsqueda.
     */
    @SuppressLint("NewApi")
    fun busquedaVuelosIda(conexionBD: ConexionBD, destino:String, fechaIda:String, fechaVuelta:String, clase:String, aerolinea:String):MutableList<Reserva>
     {
         val registrosVacios = mutableListOf<Reserva>()

        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {




                var query=""
                val partesFecha = fechaIda.split("/")
                var dia:Int=0
                var mes:Int=0
                var anio:Int=0
                if (partesFecha.size == 3) {
                    dia = partesFecha[0].toInt()
                     mes = partesFecha[1].toInt()
                     anio = partesFecha[2].toInt()

                }


                if(destino.isNotEmpty()) {
                    if(fechaIda.isNotEmpty()){
                        if(aerolinea=="Selected an Aeroline . . ."){

                            query = "SELECT  \n" +
                                    "    v.id as vuelo, aerolinea.nombre as aerolinea, \n" +
                                    "    ciudad_origen.nombre AS origen, \n" +
                                    "    ciudad_destino.nombre AS destino, \n" +
                                    "    v.fecha_salida as fecha_salida, \n" +
                                    "    v.fecha_llegada as fecha_llegada, \n" +
                                    "    aerolinea.enlace_web AS enlace\n" +
                                    "FROM aerolíneas aerolinea\n" +
                                    "JOIN aviones a ON a.id_aerolinea = aerolinea.id \n" +
                                    "JOIN vuelos v ON v.id_avion = a.id AND v.id_aerolinea = a.id_aerolinea\n" +
                                    "JOIN ciudades ciudad_origen ON ciudad_origen.id = v.id_ciudad_origen AND ciudad_origen.id_pais = v.id_pais_origen\n" +
                                    "JOIN ciudades ciudad_destino ON ciudad_destino.id = v.id_ciudad_destino AND ciudad_destino.id_pais = v.id_pais_destino\n" +
                                    "where ciudad_destino.nombre=? and  YEAR(v.fecha_salida) = ? AND MONTH(v.fecha_salida) = ? AND DAY(v.fecha_salida) = ? and v.fecha_salida >DATEADD(HOUR, 1, CURRENT_TIMESTAMP);"
                        }else{

                            query = "SELECT  \n" +
                                    "                                       v.id as vuelo, aerolinea.nombre as aerolinea, \n" +
                                    "                                        ciudad_origen.nombre AS origen,\n" +
                                    "                                        ciudad_destino.nombre AS destino,\n" +
                                    "                                        v.fecha_salida as fecha_salida,\n" +
                                    "                                        v.fecha_llegada as fecha_llegada,\n" +
                                    "                                        aerolinea.enlace_web AS enlace\n" +
                                    "                                    FROM aerolíneas aerolinea\n" +
                                    "                                    JOIN aviones a ON a.id_aerolinea = aerolinea.id \n" +
                                    "                                    JOIN vuelos v ON v.id_avion = a.id AND v.id_aerolinea = a.id_aerolinea\n" +
                                    "                                    JOIN ciudades ciudad_origen ON ciudad_origen.id = v.id_ciudad_origen AND ciudad_origen.id_pais = v.id_pais_origen\n" +
                                    "                                    JOIN ciudades ciudad_destino ON ciudad_destino.id = v.id_ciudad_destino AND ciudad_destino.id_pais = v.id_pais_destino\n" +
                                    "                                    where ciudad_destino.nombre=? and YEAR(v.fecha_salida) = ? AND MONTH(v.fecha_salida) = ? AND DAY(v.fecha_salida) = ? and aerolinea.nombre=? and v.fecha_salida >DATEADD(HOUR, 1, CURRENT_TIMESTAMP);"
                        }

                    }else {
                        if(aerolinea=="Selected an Aeroline . . .") {
                            query = "SELECT  \n" +
                                    "                                       v.id as vuelo, aerolinea.nombre as aerolinea, \n" +
                                    "                                        ciudad_origen.nombre AS origen,\n" +
                                    "                                        ciudad_destino.nombre AS destino,\n" +
                                    "                                        v.fecha_salida as fecha_salida,\n" +
                                    "                                        v.fecha_llegada as fecha_llegada,\n" +
                                    "                                        aerolinea.enlace_web AS enlace\n" +
                                    "                                    FROM aerolíneas aerolinea\n" +
                                    "                                    JOIN aviones a ON a.id_aerolinea = aerolinea.id \n" +
                                    "                                    JOIN vuelos v ON v.id_avion = a.id AND v.id_aerolinea = a.id_aerolinea\n" +
                                    "                                    JOIN ciudades ciudad_origen ON ciudad_origen.id = v.id_ciudad_origen AND ciudad_origen.id_pais = v.id_pais_origen\n" +
                                    "                                    JOIN ciudades ciudad_destino ON ciudad_destino.id = v.id_ciudad_destino AND ciudad_destino.id_pais = v.id_pais_destino\n" +
                                    "                                    where ciudad_destino.nombre=? and v.fecha_salida >DATEADD(HOUR, 1, CURRENT_TIMESTAMP);"

                        }else{
                            query = "SELECT  \n" +
                                    "                                       v.id as vuelo, aerolinea.nombre as aerolinea, \n" +
                                    "                                        ciudad_origen.nombre AS origen,\n" +
                                    "                                        ciudad_destino.nombre AS destino,\n" +
                                    "                                        v.fecha_salida as fecha_salida,\n" +
                                    "                                        v.fecha_llegada as fecha_llegada,\n" +
                                    "                                        aerolinea.enlace_web AS enlace\n" +
                                    "                                    FROM aerolíneas aerolinea\n" +
                                    "                                    JOIN aviones a ON a.id_aerolinea = aerolinea.id \n" +
                                    "                                    JOIN vuelos v ON v.id_avion = a.id AND v.id_aerolinea = a.id_aerolinea\n" +
                                    "                                    JOIN ciudades ciudad_origen ON ciudad_origen.id = v.id_ciudad_origen AND ciudad_origen.id_pais = v.id_pais_origen\n" +
                                    "                                    JOIN ciudades ciudad_destino ON ciudad_destino.id = v.id_ciudad_destino AND ciudad_destino.id_pais = v.id_pais_destino\n" +
                                    "                                    where ciudad_destino.nombre=? and aerolinea.nombre=? and v.fecha_salida >DATEADD(HOUR, 1, CURRENT_TIMESTAMP);"
                        }


                    }

                }

                val statement: PreparedStatement = conn.prepareStatement(query)

                if (destino.isNotEmpty() && fechaIda.isNotEmpty() && aerolinea!="Selected an Aeroline . . .") {



                    statement.setString(1, destino)
                    statement.setInt(2, anio)
                    statement.setInt(3,mes)
                    statement.setInt(4,dia)
                    statement.setString(5, aerolinea)

                } else if (destino.isNotEmpty() && fechaIda.isNotEmpty() && aerolinea=="Selected an Aeroline . . .") {

                    statement.setString(1, destino)
                    statement.setInt(2, anio)
                    statement.setInt(3, mes)
                    statement.setInt(4, dia)

                } else if(destino.isNotEmpty() && fechaIda.isEmpty() && aerolinea!="Selected an Aeroline . . ."){
                    statement.setString(1, destino)
                    statement.setString(2, aerolinea)
                }else if (destino.isNotEmpty()) {

                    statement.setString(1, destino)

                }




                val rs: ResultSet = statement.executeQuery()


                val registros = mutableListOf<Reserva>()

                while (rs.next()) {
                    val vuelo = Reserva()
                    vuelo.id_vuelo=rs.getString("vuelo")
                    vuelo.aerolinea = rs.getString("aerolinea")
                    vuelo.origen = rs.getString("origen")
                    vuelo.destino = rs.getString("destino")
                    vuelo.fecha_salida = rs.getString("fecha_salida")
                    vuelo.fecha_llegada = rs.getString("fecha_llegada")
                    vuelo.enlace = rs.getString("enlace")
                    registros.add(vuelo)
                }
                rs.close()
                statement.close()
                conn.close()
                return registros
            }else{

            }

        } catch (ex: Exception) {
            ex.printStackTrace()


        }
         return registrosVacios



    }

    /**
     * Obtiene las reservas de vuelo realizadas por un usuario específico basándose en su DNI.
     *
     * @param conexionBD Instancia de `ConexionBD` que permite realizar la conexión con la base de datos.
     * @param dni_usuario El DNI del usuario cuyas reservas se desean obtener.
     * @return Una lista de objetos `Reserva` con las reservas realizadas por el usuario.
     */
    fun getMisBilletes(conexionBD: ConexionBD, dni_usuario:String):MutableList<Reserva>{
        val registrosVacios = mutableListOf<Reserva>()

        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {




                var query="SELECT  \n" +
                        "v.id as vuelo, aerolinea.nombre as aerolinea, \n" +
                        "ciudad_origen.nombre AS origen, \n" +
                        "ciudad_destino.nombre AS destino, \n" +
                        "v.fecha_salida as fecha_salida, \n" +
                        "v.fecha_llegada as fecha_llegada, \n" +
                        "aerolinea.enlace_web AS enlace,\n" +
                        "r.fecha as fecha,\n" +
                        "av.numero as numero,\n" +
                        "av.letra as letra,\n" +
                        "av.tipo as tipo,\n" +
                        "r.nombre as nombre,\n" +
                        "r.apellido1 as apellido,\n" +
                        "av.id as id_asiento\n" +
                        "FROM reservas r\n" +
                        "join asientos_vuelos av on r.id_asiento_vuelo=av.id\n" +
                        "join vuelos v on v.id=av.id_vuelo\n" +
                        "JOIN ciudades ciudad_origen ON ciudad_origen.id = v.id_ciudad_origen AND ciudad_origen.id_pais = v.id_pais_origen\n" +
                        "JOIN ciudades ciudad_destino ON ciudad_destino.id = v.id_ciudad_destino AND ciudad_destino.id_pais = v.id_pais_destino\n" +
                        "join aviones a ON v.id_avion = a.id AND v.id_aerolinea = a.id_aerolinea\n" +
                        "join aerolíneas aerolinea on aerolinea.id=a.id_aerolinea\n" +
                        "where r.dni_usuario=?\n"






                val statement: PreparedStatement = conn.prepareStatement(query)

                statement.setString(1,dni_usuario)




                val rs: ResultSet = statement.executeQuery()


                val registros = mutableListOf<Reserva>()

                while (rs.next()) {
                    val vuelo = Reserva()
                    vuelo.id_vuelo=rs.getString("vuelo")
                    vuelo.aerolinea = rs.getString("aerolinea")
                    vuelo.origen = rs.getString("origen")
                    vuelo.destino = rs.getString("destino")
                    vuelo.fecha_salida = rs.getString("fecha_salida")
                    vuelo.fecha_llegada = rs.getString("fecha_llegada")
                    vuelo.enlace = rs.getString("enlace")
                    vuelo.fecha=rs.getString("fecha")
                    vuelo.numero=rs.getInt("numero").toString()
                    vuelo.letra=rs.getString("letra")
                    vuelo.tipo=rs.getString("tipo")
                    vuelo.nombre=rs.getString("nombre")
                    vuelo.apellido=rs.getString("apellido")
                    vuelo.id_asiento=rs.getInt("id_asiento").toString()
                    registros.add(vuelo)
                }
                rs.close()
                statement.close()
                conn.close()
                return registros
            }else{

            }

        } catch (ex: Exception) {
            ex.printStackTrace()


        }
        return registrosVacios
    }



}