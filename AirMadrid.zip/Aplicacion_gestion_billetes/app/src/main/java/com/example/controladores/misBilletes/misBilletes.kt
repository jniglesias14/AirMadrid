package com.example.controladores.misBilletes

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.controladores.comprarBilletes.CompraBilletes
import com.example.controladores.comprarBilletes.ReservaAdapter
import com.example.controladores.miCuenta.MiCuenta
import com.example.controladores.miMundo.MiMundo
import com.example.controladores.notificaciones.Notificaciones
import com.example.controladores.paginaPrincipal.PaginaPrincipal
import com.example.modelos.Reserva
import com.example.myapplication.R
/**
 * Actividad que muestra los billetes (reservas) del usuario, permitiéndole navegar
 * a varias secciones de la aplicación, ver información detallada sobre cada reserva
 * e interactuar con otras partes de la aplicación.
 */
class misBilletes : AppCompatActivity() {
    private lateinit var lista: ListView
    private var conexionBD = ConexionBD()
    private lateinit var home: ImageView
    private lateinit var usuario: ImageView
    private lateinit var wallet: ImageView
    private lateinit var usuarioDNI:String
    private lateinit var mundo:ImageView
    private lateinit var notificaciones:ImageView

    /**
     * Método llamado cuando la actividad es creada por primera vez. Este método configura los elementos de la UI,
     * se conecta a la base de datos y maneja las interacciones del usuario.
     *
     * @param savedInstanceState El estado guardado (si existe).
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mis_billetes)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }


        var res = conexionBD.dbConn()

        if (res == null) {
            toast_personalizado("Error de conexion con la BD")
        }

         usuarioDNI = intent.getStringExtra("usuarioDNI").toString()

        wallet = findViewById(R.id.wallet)
        wallet.setOnClickListener {
            val intent = Intent(this, CompraBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        usuario = findViewById(R.id.usuario)
        usuario.setOnClickListener {
            val intent = Intent(this, MiCuenta::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        lista = findViewById(R.id.lista)
        home = findViewById(R.id.home)
        home.setOnClickListener {
            val intent = Intent(this, PaginaPrincipal::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        mundo=findViewById(R.id.mundo)
        mundo.setOnClickListener {
            val intent = Intent(this, MiMundo::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        notificaciones=findViewById(R.id.mensaje_icono)
        notificaciones.setOnClickListener {
            val intent = Intent(this, Notificaciones::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        var elementos = mutableListOf<Reserva>()
        var registros:MutableList<Reserva>
        registros =
            usuarioDNI?.let { Reserva().getMisBilletes(conexionBD, it) }!!

        if (registros.isNotEmpty()) {
            adapter(registros, elementos)
        } else {
            toast_personalizado("There aren´t tickets")
        }

        lista.setOnItemClickListener { _, _, position, _ ->
            val reservaSeleccionada = lista.adapter.getItem(position) as Reserva
            val paquete = Bundle()

            paquete.putString("usuarioDNI",usuarioDNI)
            paquete.putString("origen",reservaSeleccionada.origen)
            paquete.putString("destino",reservaSeleccionada.destino)
            paquete.putString("salida",reservaSeleccionada.fecha_salida)
            paquete.putString("llegada",reservaSeleccionada.fecha_llegada)
            paquete.putString("nombre",reservaSeleccionada.nombre)
            paquete.putString("apellido",reservaSeleccionada.apellido)
            paquete.putString("fecha",reservaSeleccionada.fecha)
            paquete.putString("asientoLetra",reservaSeleccionada.letra)
            paquete.putString("asientoNumero",reservaSeleccionada.numero)
            paquete.putString("tipo",reservaSeleccionada.tipo)
            paquete.putString("aerolinea",reservaSeleccionada.aerolinea)
            paquete.putString("idVuelo",reservaSeleccionada.id_vuelo)
            paquete.putString("idAsiento",reservaSeleccionada.id_asiento)

            val frag = billete()
            frag.arguments = paquete

            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fragmento, frag) // Asegúrate de tener un contenedor para el fragmento
            transaction.setReorderingAllowed(true)
            transaction.addToBackStack("replacement")  // Añadir a la pila de retroceso para poder volver atrás
            transaction.commit()
        }

    }
    /**
     * Método que configura el adaptador de la lista de reservas.
     *
     * @param registros Lista de reservas obtenidas de la base de datos.
     * @param elementos Lista mutable que almacena las reservas para mostrar.
     */
    fun adapter(registros:MutableList<Reserva>, elementos:MutableList<Reserva>){
        for(i in 0 until registros.size){

            elementos.add(registros[i])
        }

        val adaptador= ReservaAdapter(
            this,
            elementos
        )
        lista.adapter=adaptador
    }

    /**
     * Muestra un Toast personalizado con el mensaje proporcionado.
     *
     * @param texto El texto que se mostrará en el Toast.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }
}