package com.example.controladores.comprarBilletes

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.modelos.AsientosVuelo
import com.example.myapplication.R

/**
 * Adaptador personalizado para mostrar una lista de asientos de vuelo en una ListView.
 *
 * Esta clase extiende BaseAdapter y se encarga de inflar el layout de cada asiento,
 * asignar los datos correspondientes y cambiar el color de la tarjeta según el estado del asiento.
 *
 * @param contexto Actividad que contiene la visualización de asientos.
 * @param asientos Lista de objetos AsientosVuelo a mostrar.
 */

class AsientosVueloAdapter(var contexto: VisualizacionAsientos, var asientos:List<AsientosVuelo>): BaseAdapter() {

    /**
     * Devuelve la cantidad de asientos en la lista.
     *
     * @return Número total de asientos.
     */
    override fun getCount(): Int {
        return asientos.size
    }

    /**
     * Devuelve el objeto AsientosVuelo en la posición especificada.
     *
     * @param position Posición del asiento en la lista.
     * @return Objeto AsientosVuelo correspondiente.
     */
    override fun getItem(position: Int): Any {
        return asientos[position]
    }

    /**
     * Devuelve el ID del asiento en la posición especificada.
     * En este caso, la posición se usa como identificador.
     *
     * @param position Posición del asiento.
     * @return ID basado en la posición.
     */
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    /**
     * Crea y configura la vista para cada elemento de la lista de asientos.
     * Cambia el color de la tarjeta según el estado del asiento:
     * - Blanco si está disponible.
     * - Rojo si está ocupado.
     * - Naranja para otros estados.
     *
     * @param position Posición del asiento en la lista.
     * @param convertView Vista reutilizable para optimización.
     * @param parent Contenedor al que se adjunta la vista.
     * @return Vista configurada para el asiento.
     */
    @SuppressLint("SuspiciousIndentation")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(contexto.requireContext()).inflate(
            R.layout.asientos,
            parent,
            false
        )

        val asiento = asientos[position]

        var tipoasiento1: TextView =view.findViewById(R.id.tipoasiento1)

        var asiento1: TextView =view.findViewById(R.id.asiento1)

        var precio1: TextView =view.findViewById(R.id.precio1)

        tipoasiento1.text=asientos[position].tipoAsiento
        asiento1.text=asientos[position].numero+asientos[position].letra
        precio1.text=asientos[position].precio+"$"

        val card = view.findViewById<androidx.cardview.widget.CardView>(R.id.cardview)
        when (asiento.estado.lowercase()) {
            "available" -> card.setCardBackgroundColor(contexto.requireContext().getColor(R.color.white))
            "occupied" -> card.setCardBackgroundColor(contexto.requireContext().getColor(R.color.rojo))
            else -> card.setCardBackgroundColor(contexto.requireContext().getColor(R.color.naranja))
        }

        return view


    }
}