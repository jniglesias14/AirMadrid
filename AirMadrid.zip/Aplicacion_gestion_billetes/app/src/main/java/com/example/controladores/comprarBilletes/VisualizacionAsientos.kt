package com.example.controladores.comprarBilletes

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.GridView
import android.widget.TextView
import android.widget.Toast
import com.example.modelos.ConexionBD
import com.example.modelos.AsientosVuelo
import com.example.modelos.Reserva
import com.example.modelos.Vuelos
import com.example.myapplication.R

/**
 * Fragmento que permite visualizar los asientos disponibles para un vuelo y realizar la selección.
 *
 */
class VisualizacionAsientos : Fragment() {
    private lateinit var lista:GridView
    private lateinit var vuelo:TextView
    private var conexionBD= ConexionBD()
    private lateinit var boton: Button
    private lateinit var id2:String
    private lateinit var id_asiento1:String

    /**
     * Método llamado cuando se crea la vista del fragmento.
     *
     * Infla el layout, inicializa las vistas y gestiona la visualización y selección de asientos.
     */
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view= inflater.inflate(R.layout.fragment_visualizacion_asientos, container, false)

        var res=conexionBD.dbConn()
        val id_vuelo= arguments?.getString("id_vuelo")
        val fecha_vuelta=arguments?.getString("fecha_vuelta")
        val aerolinea=arguments?.getString("aerolinea")
        val usuarioDni=arguments?.getString("usuarioDNI")
        id_asiento1= arguments?.getString("id_asiento1").toString()

        if(res==null) {
            toast_personalizado("Error de conexion con la BD")
        }

        lista=view.findViewById(R.id.lista)
        vuelo=view.findViewById(R.id.vuelo)
        vuelo.text=id_vuelo
        boton=view.findViewById(R.id.close)
        boton.setOnClickListener {
            parentFragmentManager.popBackStack()
        }
        var elementos= mutableListOf<AsientosVuelo>()

        var registros= id_vuelo?.let { AsientosVuelo().getAllAsientosVuelo(conexionBD, it) }

        if(registros!=null){
            for(i in 0 until registros.size){

                elementos.add(registros[i])
            }

        }

        val adaptador= AsientosVueloAdapter(
            this,
            elementos
        )
        lista.adapter=adaptador

        lista.setOnItemClickListener { _, _, position, _ ->
            if(elementos[position].estado=="available"){
                if(id_asiento1=="null"){
                    id_asiento1=elementos[position].id
                    id2=""

                }
                else{
                    id2=elementos[position].id

                }
                if(fecha_vuelta==""){

                    val intent = Intent(requireContext(), RegistroUsuarioCompraVuelo::class.java)
                    intent.putExtra("id_asiento1", id_asiento1)
                    intent.putExtra("id_asiento2",id2)
                    intent.putExtra("usuarioDNI",usuarioDni)
                    startActivity(intent)



                }else{
                    val destino= id_vuelo?.let { Vuelos().getOrigenDestino(conexionBD, it) }
                    if(destino!=null){
                        if(fecha_vuelta!=null) {
                            if(aerolinea!=null) {
                                if (Reserva().busquedaVuelosIda(
                                        conexionBD,
                                        destino,
                                        fecha_vuelta,
                                        "",
                                        "",
                                        aerolinea
                                    ).isNotEmpty()
                                ) {
                                    //cuando hay billetes de vuelta
                                    toast_personalizado2("flight availables")
                                    val intent = Intent(requireContext(), ReservaVuelo::class.java)
                                    intent.putExtra("id_asiento1", id_asiento1)
                                    intent.putExtra("id_asiento2",id2)
                                    intent.putExtra("usuarioDNI",usuarioDni)
                                    intent.putExtra("destino",destino)
                                    intent.putExtra("fechaida",fecha_vuelta)
                                    intent.putExtra("aerolinea",aerolinea)
                                    startActivity(intent)

                                }else{
                                    toast_personalizado("Not flights available")
                                    val intent = Intent(requireContext(), RegistroUsuarioCompraVuelo::class.java)
                                    intent.putExtra("id_asiento1", id_asiento1)
                                    intent.putExtra("id_asiento2",id2)
                                    intent.putExtra("usuarioDNI",usuarioDni)
                                    startActivity(intent)

                                }
                            }
                        }
                    }else{
                        toast_personalizado("Error")
                    }
                }

            }else{
                toast_personalizado("This site isn´t available")
            }
        }
        return view
    }

    /**
     * Muestra un mensaje personalizado utilizando un Toast.
     *
     * @param texto El mensaje que se mostrará en el Toast.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(this.context)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Muestra un mensaje personalizado con un diseño diferente utilizando un Toast.
     *
     * @param texto El mensaje que se mostrará en el Toast.
     */
    fun toast_personalizado2(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast2, null)

        val toast = Toast(this.context)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }


}