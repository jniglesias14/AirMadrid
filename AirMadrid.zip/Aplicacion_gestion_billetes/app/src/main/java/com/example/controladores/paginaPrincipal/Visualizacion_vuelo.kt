package com.example.controladores.paginaPrincipal

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import com.example.modelos.ConexionBD
import com.example.modelos.Vuelos
import com.example.myapplication.R

/**
 * Fragmento visualizacion_vuelo
 *
 * Este fragmento muestra los detalles de un vuelo seleccionado.
 * Los datos se obtienen a partir del identificador del vuelo pasado a través de un Bundle en los argumentos del fragmento.
 * Se conecta a la base de datos para recuperar la información del vuelo y la muestra en la interfaz.
 */
class visualizacion_vuelo : Fragment() {
    private lateinit var cerrar:Button
    private lateinit var  fecha_salida:TextView
    private lateinit var  fecha_llegada:TextView
    private lateinit var  origen:TextView
    private lateinit var  destino:TextView
    private lateinit var  terminal:TextView
    private lateinit var  puerta:TextView
    private lateinit var  aerolinea:TextView
    private lateinit var  avion:TextView
    private lateinit var  modelo:TextView
    private lateinit var  enlace:TextView
    private lateinit var  vuelo:TextView
    private var conexionBD= ConexionBD()
    /**
     * Método onCreateView
     *
     * Se encarga de inflar el layout del fragmento, inicializar los componentes visuales
     * y cargar la información del vuelo desde la base de datos.
     *
     * @param inflater El LayoutInflater que se usa para inflar la vista.
     * @param container El ViewGroup padre de la vista del fragmento.
     * @param savedInstanceState El estado previamente guardado si existía.
     * @return La vista inflada que se mostrará como interfaz del fragmento.
     */

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view= inflater.inflate(R.layout.fragment_visualizacion_vuelo, container, false)



        val id= arguments?.getString("id")
        val usuarioDNI= arguments?.getString("usuarioDNI")

        conexionBD.dbConn()


        cerrar=view.findViewById(R.id.cerrar)
        fecha_salida=view.findViewById(R.id.fecha_salida)
        fecha_llegada=view.findViewById(R.id.fecha_llegada)
        origen=view.findViewById(R.id.origen)
        destino=view.findViewById(R.id.destino)
        terminal=view.findViewById(R.id.terminal)
        puerta=view.findViewById(R.id.puerta)
        aerolinea=view.findViewById(R.id.aerolinea)
        avion=view.findViewById(R.id.avion)
        enlace=view.findViewById(R.id.enlace)
        modelo=view.findViewById(R.id.modelo)
        vuelo=view.findViewById(R.id.vuelo)

        var registroVuelo= id?.let { Vuelos().getInformacionVuelo(conexionBD, it) }
        if (registroVuelo != null) {
            vuelo.text="FLIGHT: "+registroVuelo.id_vuelo
            fecha_salida.text=""+registroVuelo.fecha_salida
            fecha_llegada.text=""+registroVuelo.fecha_llegada
            origen.text=" "+registroVuelo.origen
            destino.text=" "+registroVuelo.destino
            aerolinea.text=" "+registroVuelo.aerolinea
            avion.text=" "+registroVuelo.avion
            terminal.text=" "+registroVuelo.terminal
            puerta.text=" "+registroVuelo.puerta_embarque
            enlace.text=" "+registroVuelo.enlace
            modelo.text=" "+registroVuelo.modelo
        }

        cerrar.setOnClickListener {
            val intent = Intent(requireActivity(), PaginaPrincipal::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)

        }

        return view
    }






}