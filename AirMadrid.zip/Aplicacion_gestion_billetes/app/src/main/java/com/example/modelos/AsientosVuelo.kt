package com.example.modelos

import java.sql.PreparedStatement
import java.sql.ResultSet

/**
 * Clase que representa un asiento en un vuelo. Esta clase contiene información sobre el asiento,
 * como su tipo, precio, estado y número.
 *
 * @param id Identificador único del asiento.
 * @param tipoAsiento Tipo de asiento (Ej: clase económica, clase ejecutiva).
 * @param precio Precio del asiento.
 * @param id_vuelo Identificador del vuelo al que pertenece el asiento.
 * @param numero Número de asiento.
 * @param letra Letra del asiento (Ej: A, B, C...).
 * @param estado Estado actual del asiento (Ej: disponible, ocupado).
 */
class AsientosVuelo(
    id: String = "",
    tipoAsiento: String = "",
    precio: String = "",
    id_vuelo: String = "",
    numero: String = "",
    letra: String = "",
    estado: String = ""
) {
    var id = id
    var tipoAsiento = tipoAsiento
    var precio = precio
    var id_vuelo = id_vuelo
    var numero = numero
    var letra = letra
    var estado = estado


    /**
     * Verifica si existen asientos para un vuelo específico en la base de datos.
     * Realiza una consulta SQL para buscar asientos asociados con el identificador de vuelo proporcionado.
     *
     * @param conexionBD Instancia de `ConexionBD` para establecer la conexión a la base de datos.
     * @param id_vuelo Identificador del vuelo para verificar los asientos.
     * @return `true` si se encuentran asientos disponibles para el vuelo; `false` si no hay asientos.
     */
    fun getAsientosVuelo(conexionBD: ConexionBD, id_vuelo: String): Boolean {
        try {
            var conn = conexionBD.dbConn() // Establece la conexión
            if (conn != null) {

                val query = "select id from asientos_vuelos where id_vuelo=?"

                val statement: PreparedStatement = conn.prepareStatement(query)

                statement.setString(1, id_vuelo)


                val rs: ResultSet = statement.executeQuery()

                if (rs.next()) {

                    return true
                }


            } else {

            }

        } catch (ex: Exception) {
            ex.printStackTrace()
            return false

        }
        return false
    }

    /**
     * Obtiene todos los asientos disponibles para un vuelo específico desde la base de datos.
     * Realiza una consulta SQL para obtener todos los detalles de los asientos asociados al vuelo.
     *
     * @param conexionBD Instancia de `ConexionBD` para la conexión a la base de datos.
     * @param id_vuelo Identificador del vuelo para obtener los asientos.
     * @return Una lista de objetos `AsientosVuelo` con los detalles de los asientos disponibles.
     *         Si ocurre un error, se retorna `null`.
     */
    fun getAllAsientosVuelo(conexionBD: ConexionBD, id_vuelo: String): MutableList<AsientosVuelo>? {
        try {
            var conn = conexionBD.dbConn() // Establece la conexión
            if (conn != null) {

                val query =
                    "select id,numero,letra,tipo,precio,estado from asientos_vuelos where id_vuelo=?"

                val statement: PreparedStatement = conn.prepareStatement(query)

                statement.setString(1, id_vuelo)



                val rs: ResultSet = statement.executeQuery()
                val registros = mutableListOf<AsientosVuelo>()

                while (rs.next()) {

                    var asiento = AsientosVuelo()
                    asiento.id = rs.getInt("id").toString()
                    asiento.numero = rs.getInt("numero").toString()
                    asiento.letra = rs.getString("letra")
                    asiento.tipoAsiento = rs.getString("tipo")
                    asiento.precio = rs.getInt("precio").toString()
                    asiento.estado = rs.getString("estado")
                    registros.add(asiento)
                }
                return registros


            } else {

            }

        } catch (ex: Exception) {
            ex.printStackTrace()
            return null

        }
        return null
    }

    /**
     * Actualiza el estado de un asiento a "ocupado" en la base de datos.
     * Este método cambia el estado del asiento especificado a "ocupado".
     *
     * @param conexionBD Instancia de `ConexionBD` para realizar la conexión a la base de datos.
     * @param id_asiento Identificador del asiento a actualizar.
     */
    fun actualizarEstadoAsiento(conexionBD: ConexionBD, id_asiento: String) {
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = " update asientos_vuelos set estado=? where id=?"
                val statement: PreparedStatement = conn.prepareStatement(query)

                statement.setString(1, "occupied")
                statement.setInt(2, id_asiento.toInt())
                statement.executeUpdate()


            }
        } catch (ex: Exception) {
            ex.printStackTrace()


        }
    }

    /**
     * Actualiza el estado de un asiento a "disponible" en la base de datos.
     * Este método cambia el estado del asiento especificado a "disponible".
     *
     * @param conexionBD Instancia de `ConexionBD` para realizar la conexión a la base de datos.
     * @param id_asiento Identificador del asiento a actualizar.
     */
    fun actualizarEstadoAsientoLibre(conexionBD: ConexionBD, id_asiento: String) {
        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = " update asientos_vuelos set estado=? where id=?"
                val statement: PreparedStatement = conn.prepareStatement(query)

                statement.setString(1, "available")
                statement.setInt(2, id_asiento.toInt())
                statement.executeUpdate()


            }
        } catch (ex: Exception) {
            ex.printStackTrace()


        }
    }
}