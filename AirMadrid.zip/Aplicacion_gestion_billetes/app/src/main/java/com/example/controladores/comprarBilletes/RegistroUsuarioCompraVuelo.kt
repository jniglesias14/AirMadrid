package com.example.controladores.comprarBilletes

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.controladores.login.Registro
import com.example.controladores.miCuenta.MiCuenta
import com.example.controladores.miMundo.MiMundo
import com.example.controladores.misBilletes.misBilletes
import com.example.controladores.notificaciones.Notificaciones
import com.example.controladores.paginaPrincipal.PaginaPrincipal
import com.example.modelos.AsientosVuelo
import com.example.modelos.ReservaUsuario
import com.example.myapplication.R

/**
 * Actividad encargada de registrar un nuevo pasajero durante la compra de billetes.
 * Permite al usuario introducir sus datos personales para asignarlos a los asientos seleccionados.
 */
class RegistroUsuarioCompraVuelo : AppCompatActivity() {
    private lateinit var nombre:EditText
    private lateinit var apellido1:EditText
    private lateinit var apellido2:EditText
    private lateinit var dni:EditText
    private lateinit var email:EditText
    private lateinit var telefono:EditText
    private lateinit var boton:Button
    private var conexionBD= ConexionBD()
    private lateinit var usuarioDni:String
    private lateinit var id_asiento1:String
    private lateinit var id_asiento2:String
    private lateinit var wallet:ImageView
    private lateinit var usuario:ImageView
    private lateinit var home:ImageView
    private lateinit var misbilletes: ImageView
    private lateinit var mundo:ImageView
    private lateinit var notificaciones:ImageView

    /**
     * Método onCreate de la actividad. Inicializa la interfaz y los listeners.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_registro_usuario_compra_vuelo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var res=conexionBD.dbConn()

        if(res==null) {
            toast_personalizado("Error de conexion con la BD")
        }

        nombre=findViewById(R.id.nombre)
        apellido1=findViewById(R.id.apellido1)
        apellido2=findViewById(R.id.apellido2)
        dni=findViewById(R.id.dni)
        email=findViewById(R.id.email)
        telefono=findViewById(R.id.telefono)
        boton=findViewById(R.id.boton)

        usuarioDni = intent.getStringExtra("usuarioDNI").toString()
        id_asiento1= intent.getStringExtra("id_asiento1").toString()
        id_asiento2= intent.getStringExtra("id_asiento2").toString()


        wallet=findViewById(R.id.wallet)

        wallet.setOnClickListener {
            val intent = Intent(this, CompraBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDni)
            startActivity(intent)
        }

        misbilletes=findViewById(R.id.avion_despegue)
        misbilletes.setOnClickListener {
            val intent = Intent(this, misBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDni)
            startActivity(intent)
        }

        usuario=findViewById(R.id.usuario)
        home=findViewById(R.id.home)
        home.setOnClickListener {
            val intent = Intent(this, PaginaPrincipal::class.java)
            intent.putExtra("usuarioDNI", usuarioDni)
            startActivity(intent)
        }
        usuario.setOnClickListener {
            val intent = Intent(this, MiCuenta::class.java)
            intent.putExtra("usuarioDNI", usuarioDni)
            startActivity(intent)
        }
        mundo=findViewById(R.id.mundo)
        mundo.setOnClickListener {
            val intent = Intent(this, MiMundo::class.java)
            intent.putExtra("usuarioDNI", usuarioDni)
            startActivity(intent)
        }
        notificaciones=findViewById(R.id.mensaje_icono)
        notificaciones.setOnClickListener {
            val intent = Intent(this, Notificaciones::class.java)
            intent.putExtra("usuarioDNI", usuarioDni)
            startActivity(intent)
        }

    }

    /**
     * Método para validar los datos introducidos y realizar la compra de billetes.
     * Inserta las reservas y actualiza los asientos en la base de datos.
     */
    fun comprar(view: View){
        if(nombre.text.isEmpty() || apellido1.text.isEmpty() || apellido2.text.isEmpty() || dni.text.isEmpty() || email.text.isEmpty() || telefono.text.isEmpty()){
            toast_personalizado("A filed is empty")
        }else{
            if(comprobarDni(dni.text.toString())){
                if(comprobarTel(telefono.text.toString())){
                    if(id_asiento2==""){

                        ReservaUsuario().insertarReserva(conexionBD,usuarioDni,id_asiento1,nombre.text.toString(),apellido1.text.toString(),apellido2.text.toString(),dni.text.toString(),email.text.toString(),telefono.text.toString())
                        AsientosVuelo().actualizarEstadoAsiento(conexionBD,id_asiento1)
                        toast_personalizado2("Tickets bought successfully!")
                        val intent = Intent(this, PaginaPrincipal::class.java)
                        intent.putExtra("usuarioDNI",usuarioDni)
                        intent.putExtra("RegistroUsuarioCompraVuelo","compra")
                        startActivity(intent)
                    }else{

                        ReservaUsuario().insertarReserva(conexionBD,usuarioDni,id_asiento1,nombre.text.toString(),apellido1.text.toString(),apellido2.text.toString(),dni.text.toString(),email.text.toString(),telefono.text.toString())
                        AsientosVuelo().actualizarEstadoAsiento(conexionBD,id_asiento1)
                        ReservaUsuario().insertarReserva(conexionBD,usuarioDni,id_asiento2,nombre.text.toString(),apellido1.text.toString(),apellido2.text.toString(),dni.text.toString(),email.text.toString(),telefono.text.toString())
                        AsientosVuelo().actualizarEstadoAsiento(conexionBD,id_asiento2)
                        toast_personalizado2("Tickets bought successfully!")
                        val intent = Intent(this, PaginaPrincipal::class.java)
                        intent.putExtra("usuarioDNI",usuarioDni)
                        intent.putExtra("RegistroUsuarioCompraVuelo","compra")
                        startActivity(intent)
                    }
                }

            }
        }

    }

    /**
     * Comprueba si el teléfono tiene 9 caracteres.
     * Muestra un mensaje si el teléfono es incorrecto.
     */
    fun comprobarTel(tel:String):Boolean{
        if(tel.length!=9){
            toast_personalizado("Telephone is incorrect")
            return false
        }else{
            return true
        }
    }

    /**
     * Comprueba si el DNI tiene la longitud correcta (9 caracteres) y si el formato es válido.
     * Verifica que los primeros 8 caracteres sean dígitos y el último sea una letra mayúscula.
     */
    fun comprobarDni(dni: String): Boolean {

        if (dni.length != 9) {
            toast_personalizado("DNI is incorrect")
            return false
        }


        val numeros = dni.substring(0, 8)
        val letra = dni[8]


        if (!numeros.all { it.isDigit() }) {
            toast_personalizado("DNI is incorrect")
            return false
        }


        if (!letra.isLetter() || !letra.isUpperCase()) {
            toast_personalizado("DNI is incorrect")
            return false
        }

        return true
    }


    /**
     * Muestra un toast personalizado con un mensaje.
     *
     * @param texto Mensaje a mostrar.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Muestra un toast personalizado de éxito con un mensaje.
     *
     * @param texto Mensaje a mostrar.
     */
    fun toast_personalizado2(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast2, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Redefine el comportamiento del botón atrás para volver a la página principal
     * y limpiar la pila de actividades.
     */
    override fun onBackPressed() {
        super.onBackPressed()

        val intent = Intent(this, PaginaPrincipal::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        intent.putExtra("usuarioDNI",usuarioDni)
        startActivity(intent)
        finish()
    }
}