package com.example.modelos

import java.sql.PreparedStatement
import java.sql.ResultSet

/**
 * Clase que representa una notificación asociada a un vuelo. Las notificaciones son enviadas
 * a los usuarios para proporcionarles información importante sobre su vuelo.
 *
 * @param dni_usuario El DNI del usuario al que se le enviará la notificación.
 * @param titulo Título de la notificación.
 * @param vuelo El vuelo al que está asociada la notificación.
 * @param fecha Fecha y hora en la que se generó la notificación.
 * @param descripcion Descripción detallada de la notificación.
 */
class Notificacion(dni_usuario:String="",titulo:String="",vuelo:String="",fecha:String="",descripcion:String="") {
    var dni_usuario=dni_usuario
    var titulo=titulo
    var vuelo=vuelo
    var fecha=fecha
    var descripcion=descripcion

    /**
     * Inserta una nueva notificación en la base de datos para un vuelo específico.
     * La notificación informará al usuario de que su vuelo está a punto de salir en breve.
     *
     * @param conexionBD Instancia de `ConexionBD` para realizar la conexión a la base de datos.
     * @param id_vuelo Identificador del vuelo al cual se le asocia la notificación.
     */
    fun insertarNotificacion(conexionBD: ConexionBD, id_vuelo:String){
        try {
            val conn = conexionBD.dbConn()
            if (conn != null) {
                val sql = "INSERT INTO notificaciones_vuelos (id_vuelo, fecha, titulo, descripción) VALUES (?,  GETDATE(), ?,?)"

                val ps: PreparedStatement = conn.prepareStatement(sql)
                ps.setString(1,id_vuelo)
                ps.setString(2,"Your flight will depart in a few moments")
                ps.setString(3,"Your flight will depart in 60 minutes. Please proceed to your gate as soon as possible. We wish you a pleasant and safe journey!")
                ps.executeUpdate()


            }
        } catch (e: Exception) {
            e.printStackTrace()

        }
    }

    /**
     * Verifica si ya existe una notificación para un vuelo específico con el título de alerta,
     * para evitar duplicados de notificaciones.
     *
     * @param conexionBD Instancia de `ConexionBD` para realizar la conexión a la base de datos.
     * @param id_vuelo Identificador del vuelo que se desea verificar.
     * @return `true` si no existe una notificación con ese título para el vuelo; `false` si ya existe.
     */
    fun comprobarNotificacion(conexionBD: ConexionBD, id_vuelo:String):Boolean{

        try {
            val conn = conexionBD.dbConn()
            if (conn != null) {
                val sql = "select * from notificaciones_vuelos where id_vuelo=? and titulo=?"

                val ps: PreparedStatement = conn.prepareStatement(sql)
                ps.setString(1,id_vuelo)
                ps.setString(2,"Your flight will depart in a few moments")
                val rs: ResultSet = ps.executeQuery()

                if (rs.next()) {
                    rs.close()
                    ps.close()
                    conn.close()
                    return false
                }else{
                    rs.close()
                    ps.close()
                    conn.close()
                    return true
                }


            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return false
    }


}