package com.example.controladores.paginaPrincipal
/**
 * Interfaz Comunicador
 *
 * Esta interfaz define un método para la comunicación entre actividades o fragmentos,
 * permitiendo pasar un identificador de vuelo (o cualquier otro identificador) a otro componente.
 * Se utiliza, por ejemplo, cuando se selecciona un vuelo en una lista y se desea visualizar su información detallada.
 */
interface Comunicador {
    /**
     * Método para enviar un identificador.
     *
     * @param id Identificador del elemento (por ejemplo, id de un vuelo) que se desea comunicar.
     */
    fun pasarId(id: String)

}