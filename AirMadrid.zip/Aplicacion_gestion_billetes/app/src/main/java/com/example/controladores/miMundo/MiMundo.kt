package com.example.controladores.miMundo

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.controladores.comprarBilletes.CompraBilletes
import com.example.controladores.miCuenta.MiCuenta
import com.example.controladores.misBilletes.misBilletes
import com.example.controladores.notificaciones.Notificaciones
import com.example.controladores.paginaPrincipal.PaginaPrincipal
import com.example.modelos.Paises
import com.example.myapplication.R

/**
 * Actividad que muestra un resumen visual de los continentes visitados por el usuario
 * a través de barras de progreso y con un porcentaje correspondiente a cada continente.
 * También permite al usuario acceder a otras funcionalidades como comprar billetes,
 * ver mis billetes, acceder a la cuenta del usuario, y visualizar notificaciones.
*/
class MiMundo : AppCompatActivity() {
    private lateinit var wallet:ImageView
    private lateinit var misbilletes:ImageView
    private lateinit var usuario:ImageView
    private lateinit var home:ImageView
    private lateinit var europaporcentaje:TextView
    private lateinit var asiaporcentaje:TextView
    private lateinit var africaporcentaje:TextView
    private lateinit var americaporcentaje:TextView
    private lateinit var oceaniaporcentaje:TextView
    private lateinit var europa:ProgressBar
    private lateinit var asia:ProgressBar
    private lateinit var africa:ProgressBar
    private lateinit var america:ProgressBar
    private lateinit var oceania:ProgressBar
    private var conexionBD= ConexionBD()
    private lateinit var imageneuropa:ImageView
    private lateinit var imagenafrica:ImageView
    private lateinit var imagenasia:ImageView
    private lateinit var imagenamerica:ImageView
    private lateinit var imagenoceania:ImageView
    private lateinit var notificaciones:ImageView


    /**
     * Método que se ejecuta cuando la actividad se crea.
     *
     * Establece la vista de la actividad, configura los listeners para las imágenes y
     * inicializa los elementos visuales (como las barras de progreso) según los datos
     * del usuario. Los porcentajes y las barras de progreso reflejan las visitas a los
     * diferentes continentes del usuario.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mi_mundo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        conexionBD.dbConn()

        europaporcentaje=findViewById(R.id.texto1)
        asiaporcentaje=findViewById(R.id.texto2)
        africaporcentaje=findViewById(R.id.texto3)
        oceaniaporcentaje=findViewById(R.id.texto4)
        americaporcentaje=findViewById(R.id.texto5)
        europa=findViewById(R.id.progressBarCircular1)
        asia=findViewById(R.id.progressBarCircular2)
        africa=findViewById(R.id.progressBarCircular3)
        america=findViewById(R.id.progressBarCircular5)
        oceania=findViewById(R.id.progressBarCircular4)

        imagenasia=findViewById(R.id.imagenasia)
        imageneuropa=findViewById(R.id.imageneuropa)
        imagenamerica=findViewById(R.id.imagenamerica)
        imagenoceania=findViewById(R.id.imagenoceania)
        imagenafrica=findViewById(R.id.imagenafrica)



        val usuarioDNI = intent.getStringExtra("usuarioDNI")
        wallet=findViewById(R.id.wallet)

        wallet.setOnClickListener {
            val intent = Intent(this, CompraBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        misbilletes=findViewById(R.id.avion_despegue)
        misbilletes.setOnClickListener {
            val intent = Intent(this, misBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        usuario=findViewById(R.id.usuario)

        usuario.setOnClickListener {
            val intent = Intent(this, MiCuenta::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        home=findViewById(R.id.home)
        home.setOnClickListener {
            val intent = Intent(this, PaginaPrincipal::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        notificaciones=findViewById(R.id.mensaje_icono)
        notificaciones.setOnClickListener {
            val intent = Intent(this, Notificaciones::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        var registros= usuarioDNI?.let { Paises().getPaisesContinentesVisitados(conexionBD, it) }
        if (registros != null) {
            if(registros.isNotEmpty()){
                calcularPorcentajes(registros)
            }
        }
    }

    /**
     * Calcula los porcentajes de visitas a cada continente y actualiza las barras de progreso.
     * Además, cambia el color de las imágenes de los continentes a amarillo si hay visitas.
     *
     * @param registros Lista de países visitados por el usuario.
     */
    @SuppressLint("ResourceAsColor")
    fun calcularPorcentajes(registros: MutableList<Paises>) {
        var africaVisitas = 0
        var americaVisitas = 0
        var europaVisitas = 0
        var asiaVisitas = 0
        var oceaniaVisitas = 0

        for (i in registros.indices) {
            when (registros[i].continente) {
                "Europe" -> europaVisitas += registros[i].visitas
                "Asia" -> asiaVisitas += registros[i].visitas
                "America" -> americaVisitas += registros[i].visitas
                "Africa" -> africaVisitas += registros[i].visitas
                "Oceania" -> oceaniaVisitas += registros[i].visitas
            }
        }

        val africares = (africaVisitas.toDouble() / 54 * 100).toInt()
        val americares = (americaVisitas.toDouble() / 35 * 100).toInt()
        val europares = (europaVisitas.toDouble() / 44 * 100).toInt()
        val asiares = (asiaVisitas.toDouble() / 49 * 100).toInt()
        val oceaniares = (oceaniaVisitas.toDouble() / 14 * 100).toInt()

        europaporcentaje.text = "$europares%"
        asiaporcentaje.text = "$asiares%"
        americaporcentaje.text = "$americares%"
        africaporcentaje.text = "$africares%"
        oceaniaporcentaje.text = "$oceaniares%"

        europa.progress=europares
        asia.progress = asiares
        america.progress = americares
        africa.progress = africares
        oceania.progress = oceaniares

        if (europares != 0) {
            imageneuropa.setColorFilter(ContextCompat.getColor(this, R.color.amarillo))
        }
        if (asiares > 0) {
            imagenasia.setColorFilter(ContextCompat.getColor(this, R.color.amarillo))
        }
        if (americares > 0) {
            imagenamerica.setColorFilter(ContextCompat.getColor(this, R.color.amarillo))
        }
        if (africares > 0) {
            imagenafrica.setColorFilter(ContextCompat.getColor(this, R.color.amarillo))
        }
        if (oceaniares > 0) {
            imagenoceania.setColorFilter(ContextCompat.getColor(this, R.color.amarillo))
        }



    }

}