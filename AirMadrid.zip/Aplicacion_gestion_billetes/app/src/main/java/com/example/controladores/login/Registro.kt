package com.example.controladores.login

import android.app.DatePickerDialog
import android.content.Intent
import android.icu.text.SimpleDateFormat
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.modelos.Usuario
import com.example.myapplication.R
import java.util.Calendar
import java.util.Date
import java.util.Locale
/**
 * Actividad de registro de usuario.
 * Permite al usuario registrar una nueva cuenta proporcionando su nombre, apellidos, teléfono, correo electrónico,
 * fecha de nacimiento, DNI, nombre de usuario y contraseña.
 */

class Registro : AppCompatActivity() {
    private lateinit var name:EditText
    private lateinit var surname:EditText
    private lateinit var telephone:EditText
    private lateinit var email:EditText
    private lateinit var fecha_nac:EditText
    private lateinit var dni:EditText
    private lateinit var username:EditText
    private lateinit var password:EditText
    private var conexionBD= ConexionBD()

    /**
     * Se ejecuta cuando se crea la actividad.
     * Inicializa las vistas y establece un listener para el campo de fecha de nacimiento.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_registro)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var res=conexionBD.dbConn()
        if(res==null) {
            toast_personalizado("Error de conexion con la BD")
        }


        name=findViewById(R.id.name)
        surname=findViewById(R.id.apellido)
        telephone=findViewById(R.id.telephone)
        email=findViewById(R.id.email)
        fecha_nac=findViewById(R.id.fecha_nac)
        fecha_nac.setOnClickListener {
            seleccionFechaCum()
        }
        dni=findViewById(R.id.dni)
        username=findViewById(R.id.username)
        password=findViewById(R.id.password)

    }

    /**
     * Registra un nuevo usuario si todos los campos son válidos.
     * Comprueba que los campos no estén vacíos, que la fecha de nacimiento sea válida,
     * que el teléfono y el DNI sean correctos, y que el usuario no exista en la base de datos.
     */
    fun registrar(view: View){
        if(comprobarCampos()){
            if(comprobarFecha()){
                if(comprobarTel(telephone.text.toString())) {
                    if (comprobarDni(dni.text.toString())) {
                        if(!Usuario("","",dni.text.toString()).comprobarDNI(conexionBD )){
                                if (!Usuario(username.text.toString()).comprobarUsername(conexionBD)) {
                                    if (Usuario(
                                            username.text.toString(),
                                            password.text.toString(),
                                            dni.text.toString(),
                                            name.text.toString(),
                                            surname.text.toString(),
                                            "",
                                            fecha_nac.text.toString(),
                                            telephone.text.toString(),
                                            email.text.toString()
                                        ).insertarUsuario(conexionBD)
                                    ) {
                                        toast_personalizado2("Registration successful!")
                                        startActivity(Intent(this, InicioSesion::class.java))
                                    } else {
                                        toast_personalizado("Error")

                                    }
                                } else {
                                    toast_personalizado("Username exists")

                                }

                        }else{
                            toast_personalizado("DNI exists")

                        }
                    }
                }
            }
        }
    }
    /**
     * Redirige al usuario a la actividad de inicio de sesión al presionar el botón "Atrás".
     */
    override fun onBackPressed() {
        super.onBackPressed()

        val intent = Intent(this, InicioSesion::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    /**
     * Comprueba si el teléfono tiene 9 caracteres.
     * Muestra un mensaje si el teléfono es incorrecto.
     */
    fun comprobarTel(tel:String):Boolean{
        if(tel.length!=9){
            toast_personalizado("Telephone is incorrect")
            return false
        }else{
            return true
        }
    }

    /**
     * Comprueba si el DNI tiene la longitud correcta (9 caracteres) y si el formato es válido.
     * Verifica que los primeros 8 caracteres sean dígitos y el último sea una letra mayúscula.
     */
    fun comprobarDni(dni: String): Boolean {

        if (dni.length != 9) {
            toast_personalizado("DNI is incorrect")
            return false
        }


        val numeros = dni.substring(0, 8)
        val letra = dni[8]


        if (!numeros.all { it.isDigit() }) {
            toast_personalizado("DNI is incorrect")
            return false
        }


        if (!letra.isLetter() || !letra.isUpperCase()) {
            toast_personalizado("DNI is incorrect")
            return false
        }

        return true
    }

    /**
     * Comprueba si todos los campos obligatorios están completos.
     * Muestra un mensaje de error si algún campo está vacío.
     */
    fun comprobarCampos():Boolean{
        if(name.text.isEmpty() || surname.text.isEmpty() || telephone.text.isEmpty() || email.text.isEmpty() || fecha_nac.text.isEmpty() || dni.text.isEmpty() || username.text.isEmpty() || password.text.isEmpty()){
            toast_personalizado("A field is empty")
            return false
        }else{
            return true
        }
    }

    /**
     * Comprueba si la fecha de nacimiento es válida (mayor o igual a 18 años).
     */
    fun comprobarFecha(): Boolean {

        val fechaNacStr = fecha_nac.text.toString()

        val formatoFecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

        val fechaNac = formatoFecha.parse(fechaNacStr)

        val fechaActual = Calendar.getInstance().time

        if(calcularEdad(fechaNac,fechaActual)>=18){
            return true
        }else{
            toast_personalizado("Date is lower than 18")
            return false
        }


    }

    /**
     * Calcula la edad en base a la fecha de nacimiento y la fecha actual.
     */
    fun calcularEdad(fechaNacimiento: Date, fechaActual: Date): Int {
        val calendarioNac = Calendar.getInstance()
        calendarioNac.time = fechaNacimiento
        val calendarioActual = Calendar.getInstance()
        calendarioActual.time = fechaActual

        var edad = calendarioActual.get(Calendar.YEAR) - calendarioNac.get(Calendar.YEAR)


        if (calendarioActual.get(Calendar.MONTH) < calendarioNac.get(Calendar.MONTH) ||
            (calendarioActual.get(Calendar.MONTH) == calendarioNac.get(Calendar.MONTH) &&
                    calendarioActual.get(Calendar.DAY_OF_MONTH) < calendarioNac.get(Calendar.DAY_OF_MONTH))) {
            edad--
        }

        return edad
    }

    /**
     * Muestra un Toast personalizado con el mensaje proporcionado.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Muestra un diálogo de selección de fecha para elegir la fecha de nacimiento.
     */
    fun seleccionFechaCum() {

        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)


        val datePickerDialog = DatePickerDialog(
            this, R.style.CustomDatePickerDialog,
            { _, selectedYear, selectedMonth, selectedDay ->

                val selectedDate = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                fecha_nac.setText(selectedDate)
            },
            year, month, day
        )


        datePickerDialog.show()
    }

    /**
     * Muestra un Toast personalizado con el mensaje de éxito proporcionado.
     */
    fun toast_personalizado2(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast2, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }
}