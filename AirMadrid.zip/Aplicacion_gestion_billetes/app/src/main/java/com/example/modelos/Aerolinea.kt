package com.example.modelos

import java.sql.PreparedStatement
import java.sql.ResultSet

/**
 * Clase que representa una aerolínea. Esta clase tiene un nombre y un método para obtener todas las aerolíneas
 * desde la base de datos.
 *
 * @param nombre Nombre de la aerolínea.
 */
class Aerolinea(nombre:String="") {
    var nombre=nombre

    /**
     * Obtiene una lista de todas las aerolíneas desde la base de datos.
     * Realiza una consulta SQL a la tabla de aerolíneas y devuelve una lista de objetos `Aerolinea`
     * con el nombre de cada aerolínea encontrada.
     *
     * @param conexionBD Instancia de `ConexionBD` para realizar la conexión con la base de datos.
     * @return Una lista de objetos `Aerolinea` con los nombres de todas las aerolíneas de la base de datos.
     *         Si ocurre algún error, se retorna `null`.
     */
    fun getAerolineas(conexionBD: ConexionBD):MutableList<Aerolinea>?{

        try {
            var conn = conexionBD.dbConn()
            if (conn != null) {

                val query = "select nombre\n" +
                        "from aerolíneas;"


                val statement: PreparedStatement = conn.prepareStatement(query)

                val rs: ResultSet = statement.executeQuery()


                val registros = mutableListOf<Aerolinea>()

                while(rs.next()){

                    val aerolinea=Aerolinea()
                    aerolinea.nombre=rs.getString("nombre")
                    registros.add(aerolinea)
                }

                rs.close()
                statement.close()
                conn.close()
                return registros
            }else{

            }

        } catch (ex: Exception) {
            ex.printStackTrace()
            return null

        }
        return null
    }
}