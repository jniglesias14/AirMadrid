package com.example.controladores.misBilletes

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.annotation.RequiresApi
import com.example.modelos.ConexionBD
import com.example.modelos.AsientosVuelo
import com.example.modelos.ReservaUsuario
import com.example.myapplication.R
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

/**
 * Fragmento que muestra los detalles de un billete reservado, permitiendo al usuario ver
 * la información relevante sobre su vuelo y realizar acciones como cancelar la reserva.
 */
class billete : Fragment() {
    private lateinit var usuarioDNI:String
    private lateinit var aerolinea:TextView
    private lateinit var vuelo:TextView
    private lateinit var origen1:TextView
    private lateinit var destino1:TextView
    private lateinit var salida:TextView
    private lateinit var llegada:TextView
    private lateinit var nombre:TextView
    private lateinit var cancel:Button
    private lateinit var origen2:TextView
    private lateinit var destino2:TextView
    private lateinit var fecha:TextView
    private lateinit var asiento:TextView
    private lateinit var tipo:TextView
    private var conexionBD= ConexionBD()

    /**
     * Método llamado cuando se crea la vista del fragmento. Aquí se configura la interfaz
     * de usuario con la información pasada como argumentos y se establece la lógica de cancelación.
     *
     * @param inflater El inflador para crear la vista del fragmento.
     * @param container El contenedor de vista al que se agregará el fragmento.
     * @param savedInstanceState El estado guardado si existe.
     * @return La vista del fragmento.
     */
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val view= inflater.inflate(R.layout.fragment_billete, container, false)

        conexionBD.dbConn()

        usuarioDNI= arguments?.getString("usuarioDNI").toString()
        val origen = arguments?.getString("origen")
        val destino = arguments?.getString("destino")
        val salida1 = arguments?.getString("salida")
        val llegada1 = arguments?.getString("llegada")
        val nombre1 = arguments?.getString("nombre")
        val apellido1 = arguments?.getString("apellido")
        val fecha1 = arguments?.getString("fecha")
        val asientoLetra1 = arguments?.getString("asientoLetra")
        val asientoNumero1 = arguments?.getString("asientoNumero")
        val tipo1 = arguments?.getString("tipo")
        var aerolinea1 = arguments?.getString("aerolinea")
        val idVuelo1 = arguments?.getString("idVuelo")
        val idAsiento = arguments?.getString("idAsiento")

        aerolinea= view.findViewById(R.id.aerolinea)
        aerolinea.text=aerolinea1
        vuelo = view.findViewById(R.id.vuelo)
        vuelo.text=idVuelo1
        origen1 = view.findViewById(R.id.origen1)
        origen1.text=origen
         destino1 = view.findViewById(R.id.destino1)
        destino1.text=destino
         salida = view.findViewById(R.id.salida)
        salida.text=salida1
         llegada = view.findViewById(R.id.llegada)
        llegada.text=llegada1
         nombre = view.findViewById(R.id.nombre)
        nombre.text=nombre1+"  "+apellido1
         origen2 = view.findViewById(R.id.origen2)
        origen2.text=origen
         destino2 = view.findViewById(R.id.destino2)
        destino2.text=destino
         fecha = view.findViewById(R.id.fecha)
        fecha.text=fecha1
         asiento = view.findViewById(R.id.asiento)
        asiento.text=asientoNumero1+asientoLetra1
         tipo = view.findViewById(R.id.tipo)
        tipo.text=tipo1

        cancel=view.findViewById(R.id.cancel)
        cancel.setOnClickListener {


                if (idAsiento != null) {
                    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")
                    val salidaVuelo = LocalDateTime.parse(salida1,formatter)
                    val diasHastaVuelo = ChronoUnit.DAYS.between(LocalDateTime.now(), salidaVuelo)
                    if(salidaVuelo.isAfter(LocalDateTime.now()) && diasHastaVuelo>=3) {
                        var res=
                            idAsiento?.let { it1 ->
                                ReservaUsuario().eliminarReserva(conexionBD,usuarioDNI,
                                    it1.toInt())
                            }
                        if(res==true) {
                            AsientosVuelo().actualizarEstadoAsientoLibre(conexionBD, idAsiento)
                            val intent = Intent(requireContext(), misBilletes::class.java)
                            intent.flags =
                                Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            intent.putExtra("usuarioDNI", usuarioDNI)
                            startActivity(intent)
                            requireActivity().finish()

                        }
                    }
                }


        }

        val botonCerrar = view.findViewById<Button>(R.id.cerrar)
        botonCerrar.setOnClickListener {

            parentFragmentManager.popBackStack()
        }
        return view
    }

    /**
     * Método llamado cuando la vista ha sido completamente creada. Se maneja el comportamiento
     * del botón "atrás" para regresar al fragmento anterior.
     *
     * @param view La vista del fragmento.
     * @param savedInstanceState El estado guardado si existe.
     */
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {

                    parentFragmentManager.popBackStack()
                }
            })
    }






}