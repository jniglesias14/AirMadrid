package com.example.controladores.login

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.controladores.paginaPrincipal.PaginaPrincipal
import com.example.modelos.Usuario
import com.example.myapplication.R
import kotlin.system.exitProcess

/**
 * Actividad de la pantalla de inicio de sesión donde el usuario ingresa sus credenciales.
 * Se encarga de la autenticación del usuario, así como de la navegación hacia otras actividades,
 * como la de recuperación de contraseña o el registro de nuevos usuarios.
 */

class InicioSesion : AppCompatActivity() {
    private lateinit var icono:ImageView
    private lateinit var nombre:TextView
    private lateinit var cardView: CardView
    private lateinit var nombreUsuario:EditText
    private lateinit var password:EditText
    private lateinit var contrasenaOlvidada:TextView
    private lateinit var registrarse:TextView
    private var conexionBD= ConexionBD()
    private lateinit var usuarioDNI: String

    /**
     * Método onCreate: Se llama cuando se crea la actividad.
     * Aquí se configuran las vistas, animaciones y listeners.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_inicio_sesion)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        conexionBD.dbConn()



        contrasenaOlvidada=findViewById(R.id.contrasenaOlvidada)

        contrasenaOlvidada.setOnClickListener {
            startActivity(Intent(this, RecuperacionContasena::class.java))
        }
        registrarse=findViewById(R.id.registrarse)

        registrarse.setOnClickListener {
            startActivity(Intent(this, Registro::class.java))
        }
        icono=findViewById(R.id.icono_avion)
        nombre=findViewById(R.id.AirMadrid)
        cardView=findViewById(R.id.cardview)
        nombreUsuario=findViewById(R.id.nombreUsuario)
        password=findViewById(R.id.password)
        val animacion1=AnimationUtils.loadAnimation(this, R.anim.translacion)
        nombre.startAnimation(animacion1)
        icono.startAnimation(animacion1)
        val animacion2 = AnimationUtils.loadAnimation(this, R.anim.translacion2)
        cardView.startAnimation(animacion2)
    }

    /**
     * Método que se ejecuta cuando el usuario hace clic en el botón de iniciar sesión.
     * Valida las credenciales del usuario e inicia la actividad de la página principal si son correctas.
     */
    fun iniciar(view: View){

        var user= Usuario(nombreUsuario.text.toString(),password.text.toString())
        if(user.comprobarUsuario(conexionBD)) {
            usuarioDNI=Usuario(nombreUsuario.text.toString(),password.text.toString()).devolverDNI(conexionBD)
            if(usuarioDNI!="") {
                toast_personalizado2("Registration successful!")
                val intent = Intent(this, PaginaPrincipal::class.java)
                intent.putExtra("usuarioDNI", usuarioDNI)
                startActivity(intent)
            }
        }else{
           toast_personalizado("Error, this username or password is invalid")
        }


    }

    /**
     * Método para manejar el botón "Back" (volver atrás) y cerrar la app completamente.
     * Se asegura de que la aplicación se cierre totalmente cuando el usuario presiona atrás.
     */
    override fun onBackPressed() {
        super.onBackPressed()
        finishAffinity()
        exitProcess(0)
    }


    /**
     * Muestra un toast personalizado con el mensaje recibido.
     * @param texto El mensaje que se mostrará en el toast.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Muestra otro tipo de toast personalizado.
     * @param texto El mensaje que se mostrará en el toast.
     */
    fun toast_personalizado2(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast2, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

}