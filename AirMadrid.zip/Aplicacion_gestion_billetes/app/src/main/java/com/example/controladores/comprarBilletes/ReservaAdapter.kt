package com.example.controladores.comprarBilletes

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import com.example.modelos.Reserva
import com.example.modelos.Vuelos
import com.example.myapplication.R

/**
 * Adaptador personalizado para mostrar una lista de objetos [Reserva] en una ListView.
 *
 * @property contexto Contexto de la aplicación.
 * @property vuelos Lista de reservas a mostrar.
 */
class ReservaAdapter(var contexto: Context, var vuelos:List<Reserva>): BaseAdapter() {

    /**
     * Devuelve la cantidad de elementos en la lista de reservas.
     *
     * @return Número total de reservas.
     */
    override fun getCount(): Int {
        return vuelos.size
    }

    /**
     * Devuelve el objeto [Reserva] en una posición específica.
     *
     * @param position Posición del elemento.
     * @return Objeto [Reserva] correspondiente.
     */
    override fun getItem(position: Int): Any {
        return vuelos[position]
    }

    /**
     * Devuelve el ID del elemento en una posición específica.
     *
     * @param position Posición del elemento.
     * @return ID del elemento.
     */
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    /**
     * Método que infla y devuelve la vista correspondiente a cada elemento de la lista.
     *
     * @param position Posición del elemento en la lista.
     * @param convertView Vista reciclada, si está disponible.
     * @param parent Vista contenedora.
     * @return Vista configurada para el elemento en la posición indicada.
     */
    @SuppressLint("SuspiciousIndentation")
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View = convertView ?: LayoutInflater.from(contexto).inflate(
            R.layout.billete_vuelo,
            parent,
            false
        )

        var aerolinea:TextView=view.findViewById(R.id.aerolinea)
        var origen:TextView=view.findViewById(R.id.origen)
        var destino:TextView=view.findViewById(R.id.destino)
        var fecha_salida:TextView=view.findViewById(R.id.fecha_salida)
        var fecha_llegada:TextView=view.findViewById(R.id.fecha_llegada)
        var enlace:TextView=view.findViewById(R.id.enlace)


        aerolinea.text=vuelos[position].aerolinea
        origen.text=vuelos[position].origen
        destino.text=vuelos[position].destino
        fecha_salida.text=vuelos[position].fecha_salida
        fecha_llegada.text=vuelos[position].fecha_llegada
        enlace.text=vuelos[position].enlace

        return view


    }

}