package com.example.controladores.comprarBilletes

import android.content.Intent
import android.os.Bundle
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.modelos.ConexionBD
import com.example.controladores.miCuenta.MiCuenta
import com.example.controladores.miMundo.MiMundo
import com.example.controladores.misBilletes.misBilletes
import com.example.controladores.notificaciones.Notificaciones
import com.example.controladores.paginaPrincipal.PaginaPrincipal
import com.example.modelos.AsientosVuelo
import com.example.modelos.Reserva
import com.example.myapplication.R

/**
 * Actividad que permite a un usuario ver y seleccionar reservas de vuelos para realizar una compra.
 */
class ReservaVuelo : AppCompatActivity(),Comunicador2 {
    private lateinit var lista: ListView
    private var conexionBD = ConexionBD()
    private lateinit var home: ImageView
    private lateinit var usuario: ImageView
    private lateinit var wallet: ImageView
    private lateinit var id_asiento1:String
    private lateinit var id_asiento2:String
    private lateinit var misbilletes:ImageView
    private lateinit var mundo:ImageView
    private lateinit var notificaciones:ImageView

    /**
     * Método llamado cuando se crea la actividad.
     *
     * Configura la vista de la actividad y las interacciones de los botones.
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_reserva_vuelo)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        var res = conexionBD.dbConn()

        if (res == null) {
            toast_personalizado("Error de conexion con la BD")
        }

        val usuarioDNI = intent.getStringExtra("usuarioDNI")

        wallet = findViewById(R.id.wallet)
        wallet.setOnClickListener {
            val intent = Intent(this, CompraBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        usuario = findViewById(R.id.usuario)
        usuario.setOnClickListener {
            val intent = Intent(this, MiCuenta::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }

        home = findViewById(R.id.home)
        home.setOnClickListener {
            val intent = Intent(this, PaginaPrincipal::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        misbilletes=findViewById(R.id.avion_despegue)
        misbilletes.setOnClickListener {
            val intent = Intent(this, misBilletes::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        mundo=findViewById(R.id.mundo)
        mundo.setOnClickListener {
            val intent = Intent(this, MiMundo::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }
        notificaciones=findViewById(R.id.mensaje_icono)
        notificaciones.setOnClickListener {
            val intent = Intent(this, Notificaciones::class.java)
            intent.putExtra("usuarioDNI", usuarioDNI)
            startActivity(intent)
        }


        val destino = intent.getStringExtra("destino")
        val fechaIda = intent.getStringExtra("fechaida")
        val fechaVuelta = intent.getStringExtra("fechavuelta")
        var clase = intent.getStringExtra("clase")
        val aerolinea = intent.getStringExtra("aerolinea")
        id_asiento1= intent.getStringExtra("id_asiento1").toString()

        lista = findViewById(R.id.lista)
        var elementos = mutableListOf<Reserva>()
        var registros:MutableList<Reserva>

        if (destino != null) {
            if (fechaIda != null) {

               if(aerolinea!=null) {
                   registros =
                       Reserva().busquedaVuelosIda(conexionBD, destino, fechaIda, "", "", aerolinea)!!
                   if (registros.isNotEmpty()) {
                       adapter(registros, elementos)
                   } else {
                       toast_personalizado("no hay registros")
                   }
               }else{
                   registros =
                       Reserva().busquedaVuelosIda(conexionBD, destino, fechaIda, "", "", "")!!
                   if (registros.isNotEmpty()) {
                       adapter(registros, elementos)
                   } else {
                       toast_personalizado("no hay registros")
                   }
               }

            } else {
                registros =
                    Reserva().busquedaVuelosIda(conexionBD, destino, "", "", "", "")!!
                if (registros.isNotEmpty()) {
                    adapter(registros, elementos)
                } else {
                    toast_personalizado("no hay registros")
                }
            }


        }
        lista.setOnItemClickListener { _, _, position, _ ->
            val vueloSeleccionado = elementos[position]
            val idVuelo = vueloSeleccionado.id_vuelo

            if(AsientosVuelo().getAsientosVuelo(conexionBD,idVuelo)) {
                if (fechaVuelta != null) {
                    if (aerolinea != null) {
                        if (usuarioDNI != null) {

                            pasarDatosVuelosIda(idVuelo,fechaVuelta,aerolinea,usuarioDNI)
                        }else{

                        }
                    }
                }else{
                    if (aerolinea != null) {
                        if (usuarioDNI != null) {

                            pasarDatosVuelosIda(idVuelo,"",aerolinea,usuarioDNI)
                        }else{

                        }
                    }
                }
            }else{
                toast_personalizado("Not exists sites available yet")
            }

        }






    }

    /**
     * Configura el adaptador para mostrar las reservas de vuelos.
     *
     * @param registros Lista de reservas que se van a mostrar.
     * @param elementos Lista mutable para almacenar las reservas procesadas.
     */
    fun adapter(registros:MutableList<Reserva>,elementos:MutableList<Reserva>){
        for(i in 0 until registros.size){

            elementos.add(registros[i])
        }

        val adaptador= ReservaAdapter(
            this,
            elementos
        )
        lista.adapter=adaptador
    }

    /**
     * Muestra un toast personalizado con el mensaje proporcionado.
     *
     * @param texto El texto que se mostrará en el toast.
     */
    fun toast_personalizado(texto:String){
        val inflater = layoutInflater
        val layout = inflater.inflate(R.layout.toast, null)

        val toast = Toast(applicationContext)
        toast.duration = Toast.LENGTH_SHORT

        val textView = layout.findViewById<TextView>(R.id.toast_message)
        textView.text = texto

        toast.view = layout

        toast.show()

    }

    /**
     * Implementación del método para pasar los datos del vuelo de ida.
     *
     * @param id Identificador del vuelo.
     * @param fecha_vuelta Fecha del vuelo de vuelta.
     * @param aerolinea Aerolínea de la reserva.
     * @param usuarioDni DNI del usuario que realiza la reserva.
     */
    override fun pasarDatosVuelosIda(id:String,fecha_vuelta:String,aerolinea:String,usuarioDni:String) {

        val paquete = Bundle()
        paquete.putString("id_vuelo", id)
        paquete.putString("fecha_vuelta",fecha_vuelta)
        paquete.putString("aerolinea",aerolinea)
        paquete.putString("usuarioDNI",usuarioDni)
        paquete.putString("id_asiento1",id_asiento1)
        val frag =VisualizacionAsientos()
        frag.arguments = paquete

        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragmento, frag) // Asegúrate de tener un contenedor para el fragmento
        transaction.setReorderingAllowed(true)
        transaction.addToBackStack("replacement")  // Añadir a la pila de retroceso para poder volver atrás
        transaction.commit()



    }
}